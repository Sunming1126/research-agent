"""Export prepared artifacts and static syntax inspection; does not run tests."""
import ast
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

ROOT=Path(__file__).resolve().parent.parent
HERE=ROOT/'镜像测试'
DATA=HERE/'b-stability-20261029'
REPO=ROOT/'协同开发/research-agent-stability-20261027'
DOC=REPO/'docs/testing/2026-10-29-b-stability-study'


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def main():
    paths=[HERE/'b_stability_20261029.py',HERE/'b_stability_worker_20261029.py',
        HERE/'b_stability_counterexamples_20261029.py',ROOT/'.session-audit/prepare_b_stability_20261029.py',
        ROOT/'.session-audit/dispatch_b_stability_20261029.py',Path(__file__).resolve()]
    prototype=HERE/'审核/2026-10-29-b-stability-reference-prototype/source/src/research_agent/rag/deep_probe.py'
    syntax=[]
    for path in [*paths,prototype]:
        tree=ast.parse(path.read_text(encoding='utf-8'))
        syntax.append({'path':path.relative_to(ROOT).as_posix(),'sha256':sha(path),'ast_parse_completed':True})
    counter=ast.parse((HERE/'b_stability_counterexamples_20261029.py').read_text(encoding='utf-8'))
    names=[n.name for n in counter.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
    assert len(names)==6
    source=json.loads((DATA/'source-files.json').read_text())
    assert len(source)==193 and all(sha(REPO/n)==digest for n,digest in source.items())
    status={'status':'prepared_not_executed','source_worktree_python_files_unchanged':193,
        'source_reference_commit':'43f8189193984edd6869b5d453e4b5a0ec8c776a',
        'priority':['correctness: misses, false positives, factual support','wall time and model Tokens'],
        'counterexample_functions_prepared':names,'counterexample_variants':['0.4.17','0.4.18','reference-context prototype'],
        'counterexample_executions_planned':18,'fixed_query_executions_planned':18,'query_replay_executions_planned':6,
        'profile_executions_planned':1,'functional_tests_executed':0,'target_model_calls':0,
        'prototype_status':'hypothesis only; not applied to production, not accepted, no improvement claim',
        'why_not_executed':'Native Harness foreground verification failed; user currently cannot operate computer. Do not start independent headless tests.',
        'preparation_failure_retained':{'type':'template assertion','description':'First preparer counted indentation substring twice, including an existing nested assignment. Corrected to exact line matching before any test. This is not an agent test failure.'},
        'syntax_inspection_only':syntax,
        'limitations':['AST parsing is not a functional test','Existing literal questions are disclosed diagnostics, not held-out model relevance data',
            '30-second cProfile run cannot substantiate normal 12-second latency','Prototype only addresses known prefix reference state, not reference headings hidden in skipped pages',
            'Prototype needs new material positives/negatives, full regression and actual model accuracy/time/token measurement before adoption']}
    save(DATA/'preparation-status.json',status)
    DOC.mkdir(parents=True,exist_ok=True)
    (DOC/'.gitattributes').write_bytes(b'*.json -text -whitespace\n*.zip -text\n*.patch -text -whitespace\n')
    for name in ['manifest.json','source-files.json','baseline-source-files.json','prototype-source-files.json',
                 'preparation-status.json','reference-context-prototype.patch']:
        shutil.copyfile(DATA/name,DOC/name)
    with zipfile.ZipFile(DOC/'prepared-toolkit.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
        for path in paths:z.writestr(path.name,path.read_bytes())
    record={'artifacts':{p.name:sha(p) for p in sorted(DOC.iterdir()) if p.is_file() and p.name!='artifact-sha256.json'},
        'target_model_calls':0,'functional_tests_executed':0,'status':'prepared, not validated'}
    save(DOC/'artifact-sha256.json',record)
    print(json.dumps({'prepared_tests':6,'static_parse_files':len(syntax),'executed_tests':0,'target_model_calls':0,'production_source_changed':False}))


if __name__=='__main__':main()
