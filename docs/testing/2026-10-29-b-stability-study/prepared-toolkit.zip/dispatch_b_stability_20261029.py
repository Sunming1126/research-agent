"""Send an authorized test request to the existing visually verified Harness conversation."""
import argparse
import ctypes
from ctypes import wintypes
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / '镜像测试'))
from native_workspace_harness import workspace, native_rows, selection, EXPECTED_ID
from harness_window import focus, point, chord, type_text, window, user32

parser = argparse.ArgumentParser()
parser.add_argument('--stage', choices=['diagnostic','profile','counterexamples'], required=True)
args = parser.parse_args()
sid = 'session-9c903d0e-5884-44fe-bc7f-3719da00864b'
assert sid in workspace()['sessionIds']
selection()
user32.keybd_event(0x12, 0, 0, 0)
user32.keybd_event(0x12, 0, 2, 0)
time.sleep(.2)
try:
    focus()
except RuntimeError:
    user32.GetWindowThreadProcessId.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    user32.GetWindowThreadProcessId.restype = ctypes.c_uint
    user32.AttachThreadInput.argtypes = [ctypes.c_uint, ctypes.c_uint, ctypes.c_bool]
    caller = ctypes.windll.kernel32.GetCurrentThreadId()
    other = user32.GetWindowThreadProcessId(user32.GetForegroundWindow(), None)
    attached = user32.AttachThreadInput(caller, other, True)
    try:
        user32.ShowWindow(window(), 9)
        user32.SetForegroundWindow(window())
        time.sleep(.2)
    finally:
        if attached:
            user32.AttachThreadInput(caller, other, False)
    focus()
bounds = wintypes.RECT()
user32.GetWindowRect(window(), ctypes.byref(bounds))
assert (bounds.right-bounds.left, bounds.bottom-bounds.top) == (1941,1243)
rows, _ = native_rows(sid)
before = max((r.get('seq',0) for r in rows), default=0)
request = dict(stage=args.stage, session_id=sid, workspace_id=EXPECTED_ID, before_seq=before)
request_dir=ROOT/'.session-audit/b-stability-requests-20261029'
request_dir.mkdir(exist_ok=True)
(request_dir/(args.stage+'.json')).write_text(json.dumps(request), encoding='utf-8')
(ROOT / '.session-audit/b-stability-request-20261029.json').write_text(json.dumps(request), encoding='utf-8')
message = ('用户现已授权在固定主线下继续优化，正确率为第一标准，耗时和Token也需记录。本轮仅执行冻结输入的诊断、性能分析或参考文献边界反例。仅在本既有Agent挑战赛工作区和当前科研助手镜像验收总控对话中执行。'
           '请用原生工具只执行一次下面命令，不修改源码/测试/配置/审批策略，不另建会话，不上传赛事或推送GitHub：'
           "& 'C:/Users/lenovo/AppData/Local/Programs/Python/Python314/python.exe' -X utf8 "
           "'C:/Users/lenovo/Desktop/Agent挑战赛/镜像测试/b_stability_20261029.py' --stage " + args.stage + '。'
           '工作目录C:/Users/lenovo/Desktop/Agent挑战赛。'
           '若原生工具需要权限，请走正常审批并等待用户，不代点、不改策略。后台时监控同一任务。'
           '保留所有失败、setup错误和跳过，结束后只报告真实结果。')
message += '本阶段不调用目标真实模型，不修改生产源码，不采纳原型；所有失败保留。profile的30秒探查只用于定位热点，不能拿来证明12秒正常预算下的速度提升。'
user32.SetWindowPos.argtypes = [ctypes.c_void_p,ctypes.c_void_p,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_uint]
try:
    user32.SetWindowPos(window(),ctypes.c_void_p(-1),0,0,0,0,3)
    focus()
    time.sleep(.4)
    point(900,1084,True)
    time.sleep(.7)
    chord(0x11,0x41)
    time.sleep(.15)
    type_text(message)
    time.sleep(.5)
    chord(0x0D)
finally:
    user32.SetWindowPos(window(),ctypes.c_void_p(-2),0,0,0,0,3)
deadline=time.monotonic()+45
while time.monotonic()<deadline:
    rows, _ = native_rows(sid)
    if any(r.get('seq',0)>before and r.get('type')=='user/message'
           and 'b_stability_20261029.py' in json.dumps(r,ensure_ascii=False)
           and '--stage '+args.stage in json.dumps(r,ensure_ascii=False) for r in rows):
        print(json.dumps({'submitted':True,**request}));break
    time.sleep(.2)
else:
    raise RuntimeError('No native acknowledgement; inspect instead of resending')
