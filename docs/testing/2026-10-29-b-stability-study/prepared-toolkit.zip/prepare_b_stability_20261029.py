"""Freeze an accuracy-first diagnostic protocol; never executes agent tests."""
import hashlib
import difflib
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parent.parent
DATA=ROOT/'镜像测试/b-stability-20261029'
REPO=ROOT/'协同开发/research-agent-stability-20261027'
BASE=ROOT/'镜像测试/审核/2026-10-29-quality-baseline-a329dd6/source'
SOURCE=ROOT/'镜像测试/审核/2026-10-29-b-stability-current-43f8189/source'
PROTOTYPE=ROOT/'镜像测试/审核/2026-10-29-b-stability-reference-prototype/source'


def load(path):return json.loads(path.read_text(encoding='utf-8'))


def save_once(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    data=(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    if path.exists():assert path.read_bytes()==data,'Frozen protocol already differs'
    else:path.write_bytes(data)


def main():
    old_archive=ROOT/'镜像测试/交付/自我优化候选-0.4.17-a329dd6-20261029/research-agent-0.4.17-a329dd6-source.zip'
    assert hashlib.sha256(old_archive.read_bytes()).hexdigest()=='f282dcfc39af1527d37fd306c3475fdad5fbdf0593560d3a8eb7d3c6630aa120'
    with zipfile.ZipFile(old_archive) as z:
        old_proof={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.endswith('.py')}
    assert len(old_proof)==190 and all(hashlib.sha256((BASE/n).read_bytes()).hexdigest()==v for n,v in old_proof.items())
    archive=ROOT/'镜像测试/交付/自我优化候选-0.4.18-43f8189-20261029/research-agent-0.4.18-43f8189-source.zip'
    digest=hashlib.sha256(archive.read_bytes()).hexdigest()
    assert digest=='0cd584d8995a8650614a5942af690954f7717e6363e437bcd896e637e7796c07'
    with zipfile.ZipFile(archive) as z:
        for name in z.namelist():
            if not name.endswith('.py'):continue
            target=(SOURCE/name).resolve()
            assert target.is_relative_to(SOURCE.resolve())
            data=z.read(name)
            if target.exists():assert target.read_bytes()==data
            else:
                target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    proof=load(ROOT/'镜像测试/runs/quality-regression-20261029T170426/source-files.json')
    assert len(proof)==193 and all(hashlib.sha256((SOURCE/n).read_bytes()).hexdigest()==v for n,v in proof.items())
    assert all(hashlib.sha256((REPO/n).read_bytes()).hexdigest()==v for n,v in proof.items())
    # Prepared hypothesis only: do not change the production worktree or adopt
    # it until native counterexamples, retrieval and cost checks have run.
    for name in proof:
        target=PROTOTYPE/name;target.parent.mkdir(parents=True,exist_ok=True)
        if name!='src/research_agent/rag/deep_probe.py':
            if target.exists():assert target.read_bytes()==(SOURCE/name).read_bytes()
            else:target.write_bytes((SOURCE/name).read_bytes())
    probe=(SOURCE/'src/research_agent/rag/deep_probe.py').read_text(encoding='utf-8')
    marker='def probe_pages(index, queries, initial_page_limit, *, max_pages=1200,'
    helper='''def _prefix_reference_section(index, material, initial_page_limit):
    """Use only known, same-document prefix chunks; missing context stays unknown."""
    known = [chunk for chunk in getattr(index, 'chunks', ())
             if chunk.filename == material.filename and chunk.document_sha256 == material.sha256
             and type(chunk.page) is int and 1 <= chunk.page <= initial_page_limit]
    if not known:
        return None
    last = max(known, key=lambda chunk: (chunk.page, chunk.start))
    return last.kind == 'references'


'''
    assert marker in probe and probe.splitlines().count('                    references = False')==1
    proposal=probe.replace(marker,helper+marker,1)
    proposal=proposal.replace("    session = current_session()\n","    trace['reference_context_from_prefix'] = {}\n    session = current_session()\n",1)
    proposal=proposal.replace('\n                    references = False\n',
        "\n                    prefix_reference = _prefix_reference_section(index, material, initial_page_limit)\n"
        "                    trace['reference_context_from_prefix'][material.filename] = prefix_reference\n"
        "                    references = bool(prefix_reference)\n",1)
    proposal_path=PROTOTYPE/'src/research_agent/rag/deep_probe.py'
    proposal_bytes=proposal.encode('utf-8')
    if proposal_path.exists():assert proposal_path.read_bytes()==proposal_bytes
    else:proposal_path.write_bytes(proposal_bytes)
    patch=''.join(difflib.unified_diff(probe.splitlines(True),proposal.splitlines(True),
        fromfile='a/src/research_agent/rag/deep_probe.py',tofile='b/src/research_agent/rag/deep_probe.py'))
    DATA.mkdir(parents=True,exist_ok=True)
    patch_path=DATA/'reference-context-prototype.patch'
    if patch_path.exists():assert patch_path.read_bytes()==patch.encode('utf-8')
    else:patch_path.write_bytes(patch.encode('utf-8'))
    labels=load(ROOT/'镜像测试/depth-optimization-20261029/deep-challenge-v2.json')
    items=[]
    for row in labels['cases']:
        if row['case_id'] not in {'B-42','B-44','B-50'}:continue
        items.append({'key':row['case_id']+'-fixed','case_id':row['case_id'],'factor':'same_literal_query',
            'task':{'case_id':row['case_id'],'input':'查找正文包含此连续短语的论文：'+row['phrase']},
            'plan':{'topic':row['phrase']},'phrase':row['phrase'],'expected_filenames':row['expected_filenames']})
    live=load(ROOT/'镜像测试/runs/quality-live-20261029T172102/summary.json')
    benchmark=load(ROOT/'镜像测试/quality-20261029/benchmark.json')
    task=next(c['task'] for c in benchmark['cases'] if c['task']['case_id']=='B-44')
    for variant in ['baseline','candidate']:
        row=next(r for r in live['results'] if r['case_id']=='B-44' and r['variant']==variant)
        original=next(i for i in items if i['case_id']=='B-44')
        items.append({'key':'B-44-replay-'+variant,'case_id':'B-44','factor':'replay_frozen_query_on_same_baseline',
            'task':task,'plan':row['retrieval_trace']['query_plan'],'phrase':original['phrase'],
            'expected_filenames':original['expected_filenames']})
    manifest={'status':'frozen protocol, not executed','baseline_commit':'a329dd6cb0a2527fc664d19d55467da06086bb7e',
        'comparison_source_commit':'43f8189193984edd6869b5d453e4b5a0ec8c776a','comparison_source_zip_sha256':digest,
        'repetitions':3,'fixed_query_cases':3,'fixed_query_task_executions':18,'replayed_query_executions':6,
        'priority':['correctness including false positives and misses','case time and model Token cost'],
        'limits':{'initial_pages':4,'probe_pages':1200,'probe_seconds':12,'model_reserve_seconds':95},
        'items':items,'target_model_calls_planned':0,
        'provenance':'Existing disclosed diagnostic questions, not a new held-out set; do not tune or claim statistical significance on these outcomes',
        'acceptance':'No new strategy is accepted by this protocol alone; isolate causes, then freeze fresh positives/negatives before any proposed production fix'}
    save_once(DATA/'manifest.json',manifest)
    save_once(DATA/'source-files.json',proof)
    save_once(DATA/'baseline-source-files.json',old_proof)
    save_once(DATA/'prototype-source-files.json',{n:hashlib.sha256((PROTOTYPE/n).read_bytes()).hexdigest() for n in proof})
    save_once(DATA/'corpus.json',load(ROOT/'镜像测试/depth-optimization-20261029/corpus.json'))
    print(json.dumps({'frozen':True,'python_files':len(proof),'planned_executions':24,'executed':0,'target_model_calls':0}))


if __name__=='__main__':main()
