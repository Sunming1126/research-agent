"""Real B engine comparison worker, launched only by the verified native coordinator.

The transport uses the existing selected magic credentials in memory. Evaluation
labels never enter this process, its prompts or production source.
"""
import argparse
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parent.parent
SID = 'session-9c903d0e-5884-44fe-bc7f-3719da00864b'


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--directory', type=Path, required=True)
    args = parser.parse_args()
    directory = args.directory.resolve()
    assert directory.is_relative_to(ROOT / '镜像测试/runs')
    assert os.environ.get('ANIC_NATIVE_ORCHESTRATOR_SESSION_ID') == SID
    native = json.loads((directory.parent / 'native-proof.json').read_text(encoding='utf-8'))
    assert native['session_id'] == SID and native['native_tool_execution_verified'] and native['magic_selection_verified']
    from magic_api_bridge import MagicAPI
    from research_agent.core.engine import ResearchAgentEngine
    from research_agent.core.config import Settings
    from research_agent.integrations.llm import GatewayLLM, ModelError, ModelQuotaError
    from research_agent.core.session import remaining_timeout

    class LiveLLM(GatewayLLM):
        def __init__(self):
            super().__init__(max_calls=6, token_budget=40000, timeout=180)
            self.api = MagicAPI()
            self.model = self.api.model
            # available checks only; the adapter never exports the actual key/base URL.
            self.base_url = 'native-memory-adapter'
            self.api_key = 'unused-local-marker'

        def _request_once(self, system, prompt, requested, remaining):
            payload = {'model': self.model, 'messages': [{'role': 'system', 'content': system},
                       {'role': 'user', 'content': prompt}], 'max_tokens': requested, 'stream': False,
                       'temperature': 0, 'thinking': {'type': 'disabled'}}
            if getattr(self, 'json_response', False):
                payload['response_format'] = {'type': 'json_object'}
            try:
                value, _ = self.api.complete(payload, directory / 'model-calls' / f'{self.calls:02}',
                                            timeout=remaining_timeout(min(55, remaining)))
                return value
            except RuntimeError:
                if self.api.quota_exhausted.is_set():
                    raise ModelQuotaError('Selected magic quota exhausted') from None
                raise ModelError('Selected magic request failed; sanitized per-call metadata retained') from None

    task = json.loads((directory / 'input.json').read_text(encoding='utf-8'))
    papers = ROOT / '测试输入/交付镜像/team_share/papers'
    settings = Settings(ROOT, directory / 'output', 'b_comparison', material_roots=[papers], case_timeout=180)
    models = []
    def factory():
        model = LiveLLM()
        models.append(model)
        return model
    started = time.monotonic()
    try:
        answer = ResearchAgentEngine(settings, llm_factory=factory).solve_sync(task)
        saved = directory / 'output/data/b_comparison' / (task['case_id'] + '.json')
        assert json.loads(saved.read_text(encoding='utf-8')) == answer
        result = {'status': 'completed', 'answer': answer, 'disk_matches': True}
    except Exception as exc:
        result = {'status': 'failed', 'error_type': type(exc).__name__, 'disk_matches': False}
    calls = [json.loads(p.read_text(encoding='utf-8')) for p in (directory / 'model-calls').glob('*/call.json')]
    result.update(seconds=round(time.monotonic() - started, 3), target_real_model_calls=len(calls),
                  total_tokens=sum((c.get('usage') or {}).get('total_tokens', 0) for c in calls),
                  quota_exhausted=any(m.api.quota_exhausted.is_set() for m in models),
                  model=models[0].model if models else None,
                  environment='Windows source engine with real magic transport; not image or official HTTP acceptance')
    save(directory / 'result.json', result)
    print(json.dumps({k: v for k, v in result.items() if k != 'answer'}, ensure_ascii=False))


if __name__ == '__main__':
    main()
