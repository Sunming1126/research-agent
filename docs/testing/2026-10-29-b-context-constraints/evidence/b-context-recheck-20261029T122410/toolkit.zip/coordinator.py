"""Native Harness coordinator; all target execution requires a fresh fixed-session tool call."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent.parent
SOURCE = ROOT / '协同开发/research-agent-stability-20261027'
BASE = ROOT / '镜像测试/审核/2026-10-29-context-baseline-5a8227c/source'
SID = 'session-9c903d0e-5884-44fe-bc7f-3719da00864b'
WID = 'c61ec5e8-9932-4ef5-9709-fed302ad7355'


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def proof(stage):
    from native_workspace_harness import workspace, native_rows, selection
    assert SID in workspace()['sessionIds']
    selection()
    request = json.loads((ROOT / '.session-audit/context-optimization-request.json').read_text(encoding='utf-8'))
    assert request['stage'] == stage and request['session_id'] == SID and request['workspace_id'] == WID
    for _ in range(30):
        rows, _ = native_rows(SID)
        for row in rows:
            if row.get('seq', 0) <= request['before_seq'] or row.get('type') != 'assistant/message':
                continue
            for part in row.get('data', {}).get('message', {}).get('content', []):
                text = json.dumps(part, ensure_ascii=False)
                if part.get('type') == 'tool-call' and 'b_context_20261029.py' in text and '--stage ' + stage in text:
                    return dict(session_id=SID, workspace_id=WID, native_tool_execution_verified=True,
                                magic_selection_verified=True, tool_sha256=hashlib.sha256(text.encode()).hexdigest())
        time.sleep(.2)
    raise RuntimeError('No fresh authorized native invocation in required conversation')


def run_tests(source, directory, files, disable=()):
    directory.mkdir()
    paths = [str(source), str(source / 'src'), str(SOURCE / 'tests'), str(ROOT / '镜像测试/runtime/py312-windows')]
    boot = 'import sys;sys.path[:0]=' + repr(paths) + ';'
    if disable:
        boot += 'import research_agent.workflows.tasks as t;'
        if 'coverage' in disable:
            boot += 't.select_evidence=lambda hits,queries,limit=3:hits[:limit];'
        if 'window' in disable:
            boot += 't.compact_retrieval_chunk=lambda c,queries:dict(chunk_id=c.chunk_id,page=c.page,heading=c.heading,text=c.text[:1100]);'
        if 'batch' in disable:
            boot += 't.evidence_batches=lambda rows,task,llm:[rows[i:i+6] for i in range(0,len(rows),6)];'
    boot += 'import pytest;raise SystemExit(pytest.main(sys.argv[1:]))'
    env = os.environ.copy()
    env.update(PYTHONDONTWRITEBYTECODE='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', RESEARCH_RUNTIME='local',
               AGENTHACK_TELEMETRY_REQUIRED='false', RESEARCH_TEST_PAPERS=str(ROOT / '测试输入/交付镜像/team_share/papers'),
               PUBLIC_EXPERIMENT_ROOT=str(ROOT / '测试输入/交付镜像/team_share/experiments/research-experiments'),
               TEMP=str(directory), TMP=str(directory), TMPDIR=str(directory))
    cmd = [str(ROOT / '镜像测试/runtime/windows-python312/python.exe'), '-X', 'utf8', '-c', boot,
           '-q', '-p', 'no:cacheprovider', '--basetemp=' + str(directory / 'temp'),
           '--junitxml=' + str(directory / 'pytest.xml'), *map(str, files)]
    started = time.monotonic()
    done = subprocess.run(cmd, cwd=source, env=env, capture_output=True, timeout=480)
    (directory / 'stdout.txt').write_bytes(done.stdout)
    (directory / 'stderr.txt').write_bytes(done.stderr)
    cases = ET.parse(directory / 'pytest.xml').getroot().findall('.//testcase') if (directory / 'pytest.xml').is_file() else []
    counts = dict(collected=len(cases), failures=sum(c.find('failure') is not None for c in cases),
                  errors=sum(c.find('error') is not None for c in cases), skipped=sum(c.find('skipped') is not None for c in cases))
    counts['passed'] = counts['collected'] - counts['failures'] - counts['errors'] - counts['skipped']
    result = dict(returncode=done.returncode, **counts, seconds=round(time.monotonic() - started, 3),
                  environment='Windows isolated Python 3.12.14 source regression; not Linux image acceptance',
                  target_real_model_calls=0)
    save(directory / 'summary.json', result)
    save(directory / 'command.json', cmd)
    print(json.dumps(dict(run=str(directory), **result), ensure_ascii=False), flush=True)
    return result


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', choices=['simulate', 'semantics', 'regression', 'live', 'holdout', 'recheck'], required=True)
    options = parser.parse_args()
    native = proof(options.stage)
    directory = ROOT / '镜像测试/runs' / ('b-context-' + options.stage + '-' + time.strftime('%Y%m%dT%H%M%S'))
    directory.mkdir(parents=True, exist_ok=False)
    save(directory / 'native-proof.json', native)
    toolkit = {'coordinator.py': Path(__file__), 'live-worker.py': ROOT / '镜像测试/b_live_worker_20261029.py'}
    with zipfile.ZipFile(directory / 'toolkit.zip', 'x', compression=zipfile.ZIP_DEFLATED) as archive:
        for name, path in toolkit.items():
            archive.writestr(name, path.read_bytes())
    save(directory / 'toolkit-sha256.json', {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in toolkit.items()})
    save(ROOT / ('.session-audit/b-context-' + options.stage + '-latest.json'), {'run': str(directory)})
    save(directory / 'source-files.json', {p.relative_to(SOURCE).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
         for p in SOURCE.rglob('*.py') if '__pycache__' not in p.parts})
    os.environ['ANIC_NATIVE_ORCHESTRATOR_SESSION_ID'] = SID
    if options.stage == 'semantics':
        test = SOURCE / 'tests/test_b_context_constraints.py'
        save(directory / 'counterexample-sha256.json', {'test': hashlib.sha256(test.read_bytes()).hexdigest()})
        first = run_tests(BASE, directory / 'baseline', [test])
        second = run_tests(SOURCE, directory / 'candidate', [test])
        save(directory / 'summary.json', {'baseline': first, 'candidate': second, 'mock_reader_not_semantic_benchmark': True})
        return
    if options.stage == 'simulate':
        test = SOURCE / 'tests/test_b_evidence_counterexamples.py'
        save(directory / 'counterexample-sha256.json', {'test': hashlib.sha256(test.read_bytes()).hexdigest()})
        first = run_tests(BASE, directory / 'baseline', [test])
        ablations = {}
        for name, disable in [('coverage_only', ('window', 'batch')), ('window_only', ('coverage', 'batch')),
                              ('batch_only', ('coverage', 'window')), ('coverage_window', ('batch',)),
                              ('coverage_batch', ('window',)), ('window_batch', ('coverage',)), ('candidate', ())]:
            ablations[name] = run_tests(SOURCE, directory / name, [test], disable=disable)
        save(directory / 'summary.json', {'baseline': first, 'ablations': ablations,
             'candidate': ablations['candidate'], 'mock_reader_not_semantic_benchmark': True})
        return
    if options.stage == 'regression':
        result = run_tests(SOURCE, directory / 'candidate', [SOURCE / 'tests'])
        save(directory / 'summary.json', result)
        raise SystemExit(result['returncode'])
    # Live worker is separate from the evaluation labels. Each case gets a fresh process/cache/output.
    manifest = ROOT / '镜像测试/context-optimization-20261029' / ('holdout.json' if options.stage == 'holdout' else 'recheck.json' if options.stage == 'recheck' else 'benchmark.json')
    if not manifest.is_file():
        raise RuntimeError('Frozen independent benchmark not prepared')
    labels = json.loads(manifest.read_text(encoding='utf-8'))
    save(directory / 'benchmark.json', labels)
    results = []
    for index, item in enumerate(labels['cases']):
        order = [('baseline', BASE), ('candidate', SOURCE)] if index % 2 == 0 else [('candidate', SOURCE), ('baseline', BASE)]
        for variant, source in order:
            out = directory / (item['task']['case_id'] + '-' + variant)
            out.mkdir()
            save(out / 'input.json', item['task'])
            env = os.environ.copy()
            env.update(PYTHONDONTWRITEBYTECODE='1', RESEARCH_RUNTIME='local', AGENTHACK_TELEMETRY_REQUIRED='false',
                       ANIC_NATIVE_ORCHESTRATOR_SESSION_ID=SID)
            paths = [str(source), str(source / 'src'), str(ROOT / '镜像测试/runtime/py312-windows'), str(ROOT / '镜像测试')]
            boot = 'import sys,runpy;sys.path[:0]=' + repr(paths) + ';runpy.run_path(' + repr(str(ROOT / '镜像测试/b_live_worker_20261029.py')) + ',run_name="__main__")'
            cmd = [str(ROOT / '镜像测试/runtime/windows-python312/python.exe'), '-X', 'utf8', '-c', boot, '--directory', str(out)]
            try:
                done = subprocess.run(cmd, cwd=source, env=env, capture_output=True, timeout=220)
            except subprocess.TimeoutExpired as exc:
                (out / 'stdout.txt').write_bytes(exc.stdout or b'')
                (out / 'stderr.txt').write_bytes(exc.stderr or b'')
                row = {'status': 'worker_timeout', 'error_type': 'TimeoutExpired', 'disk_matches': False,
                       'target_real_model_calls': None, 'usage_unknown': True}
                save(out / 'worker-timeout.json', row)
            else:
                (out / 'stdout.txt').write_bytes(done.stdout)
                (out / 'stderr.txt').write_bytes(done.stderr)
                row = json.loads((out / 'result.json').read_text(encoding='utf-8')) if (out / 'result.json').is_file() else {'status': 'setup_failed', 'returncode': done.returncode}
            selected = {p['filename'] for p in row.get('answer', {}).get('papers', [])}
            expected = set(item['expected_filenames'])
            row.update(case_id=item['task']['case_id'], variant=variant, hits=len(selected & expected),
                       missed=sorted(expected - selected), false_positives=sorted(selected - expected),
                       expected=len(expected), exact=row.get('status') == 'completed' and row.get('disk_matches') is True and selected == expected)
            results.append(row)
            save(directory / 'summary.json', {'results': results, 'complete': False, 'image_acceptance': False})
            print(json.dumps({k: v for k, v in row.items() if k != 'answer'}, ensure_ascii=False), flush=True)
            if row.get('quota_exhausted'):
                return
    save(directory / 'summary.json', {'results': results, 'complete': True, 'image_acceptance': False})


if __name__ == '__main__':
    main()
