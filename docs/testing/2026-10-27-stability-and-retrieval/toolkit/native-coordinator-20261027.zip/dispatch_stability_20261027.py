"""Dispatch only to the already visually verified, fixed existing Harness conversation."""
import argparse
import ctypes
import json
from pathlib import Path
import sys
import time
from ctypes import wintypes

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / '镜像测试'))
from native_workspace_harness import workspace, native_rows, selection, EXPECTED_ID
from harness_window import focus, point, chord, type_text, window, user32

parser = argparse.ArgumentParser()
parser.add_argument('--stage', choices=['baseline', 'regression', 'host-baseline', 'host-regression', 'host-validation'], required=True)
args = parser.parse_args()
saved = json.loads((ROOT / '.session-audit/native-api-main-conversation.json').read_text(encoding='utf-8'))
assert saved['session_id'] in workspace()['sessionIds'] and saved['workspace_id'] == EXPECTED_ID
selection()
try:
    try:
        focus()
    except RuntimeError:
        # Release the standard foreground lock with a harmless Alt keystroke, then re-verify.
        # No text or command is sent unless focus() subsequently confirms the exact Harness HWND.
        user32.keybd_event(0x12, 0, 0, 0)
        user32.keybd_event(0x12, 0, 2, 0)
        user32.SetForegroundWindow(window())
        time.sleep(.2)
        focus()
except RuntimeError:
    # Windows foreground lock: join input queues briefly to focus only this existing window.
    user32.GetWindowThreadProcessId.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    user32.GetWindowThreadProcessId.restype = ctypes.c_uint
    user32.AttachThreadInput.argtypes = [ctypes.c_uint, ctypes.c_uint, ctypes.c_bool]
    caller_thread = ctypes.windll.kernel32.GetCurrentThreadId()
    foreground_thread = user32.GetWindowThreadProcessId(user32.GetForegroundWindow(), None)
    attached = user32.AttachThreadInput(caller_thread, foreground_thread, True)
    try:
        user32.ShowWindow(window(), 9)
        user32.SetForegroundWindow(window())
        time.sleep(.2)
    finally:
        if attached:
            user32.AttachThreadInput(caller_thread, foreground_thread, False)
    focus()
bounds = wintypes.RECT()
user32.GetWindowRect(window(), ctypes.byref(bounds))
assert (bounds.right - bounds.left, bounds.bottom - bounds.top) == (1941, 1243)
rows, _ = native_rows(saved['session_id'])
before = max((r.get('seq', 0) for r in rows), default=0)
request = {'session_id': saved['session_id'], 'workspace_id': EXPECTED_ID, 'stage': args.stage,
           'before_seq': before, 'workspace_bound_before_call': True, 'provider': 'magic'}
(ROOT / '.session-audit/native-stability-request.json').write_text(json.dumps(request, indent=2), encoding='utf-8')
message = ('用户今天已授权两小时稳定性优化，队友main现为c443883，0.4.13。继续使用本固定总控对话和Agent挑战赛工作区、magic。'
    '新的独立Git工作副本在协同开发/research-agent-stability-20261027；它不是新Harness工作区。'
    '请只用本对话原生工具执行一次以下协调器，不修改任何代码/测试/配置，不自动继续其他阶段。'
    f"& 'C:/Users/lenovo/AppData/Local/Programs/Python/Python314/python.exe' 'C:/Users/lenovo/Desktop/Agent挑战赛/镜像测试/native_stability_20261027.py' --stage {args.stage}。"
    '工作目录C:/Users/lenovo/Desktop/Agent挑战赛。baseline预期可能出现故障反例失败，原样保存，不修复或改判；regression也原样保存失败。'
    '本步只用离线夹具，不调用真实目标模型；Docker若需要原生审批，正常发起并等用户，不能绕过或修改策略。'
    '后台执行则等待同一任务；完成后报告实际运行目录和数量。不得创建对话，不上传赛事，不推送GitHub。')
if args.stage.startswith('host-'):
    message += ('Docker因Windows损坏socket尚未恢复；本步是明确分开的Windows Python3.12源码离线故障验证，'
                '不访问Docker，不冒充Linux/1CPU/1GiB镜像验收。使用已准备的本机隔离测试依赖和未改动官方SDK副本。'
                '用户已说明当前只自我优化，不上传平台。工具如可用默认权限先正常执行；若必须审批则正常申请。')
    if args.stage == 'host-regression':
        message += ('冻结main六项故障现已真实复现，原证据T205642保留。候选已为Windows不支持的UnixStreamServer模块加显式环境skip，'
                    '不改Linux断言；本次只跑候选完整回归。请使用已验证必要的一次性danger-full-access原生审批来执行此离线任务，'
                    '正常请求用户并等待，不重试受限令牌导致的mode700临时目录错误，不修改策略。')
if args.stage == 'host-validation':
    command = ("& 'C:/Users/lenovo/AppData/Local/Programs/Python/Python314/python.exe' "
               "'C:/Users/lenovo/Desktop/Agent挑战赛/镜像测试/native_stability_20261027.py' --stage ")
    message = ('继续已授权的本地自我优化，不上传打榜、不改SDK。Codex已修正隔离依赖读取权限，'
               'Windows受限令牌仍无法访问pytest按mode700新建的临时目录，工作区basetemp也已实证失败。'
               '本次请用Harness原生danger-full-access的一次性审批执行下面整条离线命令；必须正常申请并等用户批准，不改审批策略、执行策略或ACL。'
               '单次工具调用依次运行冻结main六项baseline及候选完整regression，baseline预计故障反例失败，原样保留后继续regression。'
               '只执行下面这一条，不擅自修改源码、测试、断言、配置、依赖。'
               + command + 'host-baseline; ' + command + 'host-regression。'
               '工作目录C:/Users/lenovo/Desktop/Agent挑战赛。两个阶段均为Windows Python3.12离线源码测试，'
               '不访问Docker、不调用目标真实模型、不冒充Linux/1CPU/1GiB镜像验收，不新建会话或工作区，不推送GitHub。'
               '后台时监控同一任务直至结束，报告两个实际目录、通过/断言失败/环境setup错误/跳过分别多少。')
user32.SetWindowPos.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_uint]
try:
    # Temporarily bring this already verified window above unrelated always-on-top windows.
    # Never interact with or dismiss another application's window or an approval dialog.
    user32.SetWindowPos(window(), ctypes.c_void_p(-1), 0, 0, 0, 0, 3)
    focus()
    point(900, 1080, True)
    chord(0x11, 0x41)
    type_text(message)
    time.sleep(.5)
    chord(0x0D)
finally:
    user32.SetWindowPos(window(), ctypes.c_void_p(-2), 0, 0, 0, 0, 3)
for _ in range(50):
    rows, _ = native_rows(saved['session_id'])
    if any(r.get('seq', 0) > before and r.get('type') == 'user/message'
           and 'native_stability_20261027.py' in json.dumps(r, ensure_ascii=False)
           and ('--stage ' + args.stage in json.dumps(r, ensure_ascii=False)
                or args.stage == 'host-validation' and '--stage host-baseline' in json.dumps(r, ensure_ascii=False)
                and '--stage host-regression' in json.dumps(r, ensure_ascii=False)) for r in rows):
        print(json.dumps({'submitted': True, **request}))
        break
    time.sleep(.2)
else:
    raise RuntimeError('No native acknowledgment; inspect before retrying')
