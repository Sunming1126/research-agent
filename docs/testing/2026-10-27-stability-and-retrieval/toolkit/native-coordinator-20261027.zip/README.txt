Historical coordinator snapshot, not a portable standalone runner.
Only launch tests through the existing authorized Harness workspace and fixed native conversation.
Local native_workspace_harness.py / harness_window.py helpers and approved test dependencies are prerequisites.
Host stages use Windows source, not an image. The unused Docker regression stage excludes a module and is not full image acceptance.
No credentials, profile files, workspace configuration or API keys are included.
