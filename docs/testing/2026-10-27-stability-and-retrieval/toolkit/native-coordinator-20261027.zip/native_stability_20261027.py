"""Run only from a new native tool invocation in the fixed Harness main conversation."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent.parent
HERE = ROOT / '镜像测试'
SOURCE = ROOT / '协同开发/research-agent-stability-20261027'
BASELINE = HERE / '审核/2026-10-27-stability-main-c443883/source'
SID = 'session-9c903d0e-5884-44fe-bc7f-3719da00864b'
WID = 'c61ec5e8-9932-4ef5-9709-fed302ad7355'
ORIGINAL = 'research-assistant:0.4.13-c-20261026'
DOCKER = str(Path.home() / 'AppData/Local/Programs/DockerDesktop/resources/bin/docker.exe')

def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def proof(stage):
    from native_workspace_harness import workspace, native_rows, selection
    assert SID in workspace()['sessionIds']
    selection()
    request = json.loads((ROOT / '.session-audit/native-stability-request.json').read_text(encoding='utf-8'))
    assert request['session_id'] == SID and request['workspace_id'] == WID
    assert request['stage'] == stage or (request['stage'] == 'host-validation' and stage in {'host-baseline', 'host-regression'})
    for _ in range(30):
        rows, _ = native_rows(SID)
        for row in rows:
            if row.get('seq', 0) <= request['before_seq'] or row.get('type') != 'assistant/message':
                continue
            for part in row.get('data', {}).get('message', {}).get('content', []):
                text = json.dumps(part, ensure_ascii=False)
                if part.get('type') == 'tool-call' and 'native_stability_20261027.py' in text and '--stage ' + stage in text:
                    os.environ['ANIC_NATIVE_ORCHESTRATOR_SESSION_ID'] = SID
                    return {'session_id': SID, 'workspace_id': WID, 'native_tool_execution_verified': True,
                            'tool_sha256': hashlib.sha256(text.encode()).hexdigest(), 'magic_selection_verified': True}
        time.sleep(.2)
    raise RuntimeError('No new native tool invocation in the required workspace conversation')

def main():
    sys.stdout.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', choices=['baseline', 'regression', 'host-baseline', 'host-regression'], required=True)
    options = parser.parse_args()
    native = proof(options.stage)
    source = BASELINE if options.stage in {'baseline', 'host-baseline'} else SOURCE
    if options.stage.startswith('host-'):
        directory = HERE / 'runs' / ('stability-0414-' + options.stage + '-' + time.strftime('%Y%m%dT%H%M%S'))
        directory.mkdir(parents=True, exist_ok=False)
        save(directory / 'native-orchestration-proof.json', native)
        save(ROOT / ('.session-audit/native-stability-' + options.stage + '-latest.json'), {'run': str(directory)})
        files = {p.relative_to(source).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                 for p in source.rglob('*.py') if '__pycache__' not in p.parts}
        save(directory / 'source-files.json', files)
        save(directory / 'testkit.json', {'tests': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (SOURCE / 'tests').glob('*.py')},
             'coordinator_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
        executable = Path.home() / '.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
        private_python = HERE / 'runtime/windows-python312/python.exe'
        if private_python.is_file():
            executable = private_python
        env = os.environ.copy()
        env.update(PYTHONPATH=os.pathsep.join(map(str, [source, source / 'src', SOURCE / 'tests', HERE / 'runtime/py312-windows'])),
                   PYTHONDONTWRITEBYTECODE='1', RESEARCH_RUNTIME='local', AGENTHACK_TELEMETRY_REQUIRED='false',
                   RESEARCH_TEST_PAPERS=str(ROOT / '测试输入/交付镜像/team_share/papers'),
                   PUBLIC_EXPERIMENT_ROOT=str(ROOT / '测试输入/交付镜像/team_share/experiments/research-experiments'))
        env['PATH'] = str(executable.parent) + os.pathsep + env.get('PATH', '')
        temp_root = directory / 'temp'
        temp_root.mkdir()
        env.update(TEMP=str(temp_root), TMP=str(temp_root), TMPDIR=str(temp_root), PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
        selected = [str(SOURCE / 'tests/test_submission_stability.py')] if options.stage == 'host-baseline' else [str(SOURCE / 'tests')]
        # Bundled Python uses an isolated _pth file, so PYTHONPATH alone is ignored.
        # Bootstrap only this child process's sys.path; never edit the runtime or user profiles.
        search_paths = list(map(str, [source, source / 'src', SOURCE / 'tests', HERE / 'runtime/py312-windows']))
        bootstrap = 'import sys; sys.stdout.reconfigure(encoding="utf-8"); sys.stderr.reconfigure(encoding="utf-8"); sys.path[:0]=' + repr(search_paths) + '; import pytest; raise SystemExit(pytest.main(sys.argv[1:]))'
        args = [str(executable), '-X', 'utf8', '-c', bootstrap, '-q', '-p', 'no:cacheprovider', '--basetemp=' + str(temp_root / 'pytest'),
                '--junitxml=' + str(directory / 'pytest.xml'), *selected]
        started = time.monotonic()
        completed = subprocess.run(args, cwd=source, env=env, capture_output=True, timeout=420)
        (directory / 'pytest.stdout.txt').write_bytes(completed.stdout)
        (directory / 'pytest.stderr.txt').write_bytes(completed.stderr)
        save(directory / 'pytest.result.json', {'returncode': completed.returncode, 'args': args})
        counts = {}
        if (directory / 'pytest.xml').exists():
            cases = ET.parse(directory / 'pytest.xml').getroot().findall('.//testcase')
            counts = {'collected': len(cases), 'failed': sum(c.find('failure') is not None or c.find('error') is not None for c in cases),
                      'skipped': sum(c.find('skipped') is not None for c in cases)}
            counts['passed'] = counts['collected'] - counts['failed'] - counts['skipped']
        summary = {'stage': options.stage, 'returncode': completed.returncode, **counts, 'seconds': round(time.monotonic() - started, 3),
                   'real_model_calls': 0, 'environment': 'Windows Python 3.12.14, isolated test dependencies; no Docker resource limit',
                   'image_acceptance': False, 'source_fingerprint': hashlib.sha256(json.dumps(files, sort_keys=True).encode()).hexdigest()}
        save(directory / 'summary.json', summary)
        print(completed.stdout.decode('utf-8', errors='replace'))
        print(completed.stderr.decode('utf-8', errors='replace'))
        print(json.dumps({'directory': str(directory), **summary}, ensure_ascii=False))
        raise SystemExit(completed.returncode)
    image = subprocess.run([DOCKER, 'image', 'inspect', ORIGINAL, '--format', '{{.Id}}'], capture_output=True, timeout=30)
    if image.returncode:
        archive = ROOT / '镜像测试/交付/队友main-0.4.13-c-20261026-c443883/research-assistant-0.4.13-c-20261026.tar'
        with archive.open('rb') as f:
            assert hashlib.file_digest(f, 'sha256').hexdigest() == '3cd86ada7c1dd3782dac1c56e7c05e4bd7ca23e54d3d57faaaec0ddb9e92ff36'
        subprocess.run([DOCKER, 'load', '-i', str(archive)], check=True, timeout=240)
        image = subprocess.run([DOCKER, 'image', 'inspect', ORIGINAL, '--format', '{{.Id}}'], capture_output=True, check=True, timeout=30)
    directory = HERE / 'runs' / ('stability-0414-' + options.stage + '-' + time.strftime('%Y%m%dT%H%M%S'))
    directory.mkdir(parents=True, exist_ok=False)
    save(directory / 'native-orchestration-proof.json', native)
    save(ROOT / ('.session-audit/native-stability-' + options.stage + '-latest.json'), {'run': str(directory)})
    files = {p.relative_to(source).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
             for p in source.rglob('*.py') if '__pycache__' not in p.parts and (p.parts[len(source.parts)] in {'src', 'tests'} or p.parent == source)}
    save(directory / 'source-files.json', files)
    args = [DOCKER, 'run', '--rm', '--pull=never', '--network', 'none', '--read-only', '--cpus', '1', '--memory', '1024m',
        '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges', '--tmpfs', '/tmp:rw,nosuid,size=256m',
        '-e', 'PYTHONDONTWRITEBYTECODE=1', '-e', 'PYTHONPATH=/src:/src/src:/tests:/deps', '-e', 'RESEARCH_RUNTIME=local',
        '-e', 'AGENTHACK_TELEMETRY_REQUIRED=false',
        '--mount', f'type=bind,source={source},target=/src,readonly',
        '--mount', f'type=bind,source={SOURCE / "tests"},target=/tests,readonly',
        '--mount', f'type=bind,source={ROOT / "协同开发/research-agent/output/test-deps"},target=/deps,readonly',
        '--mount', f'type=bind,source={ROOT / "测试输入/交付镜像/team_share/papers"},target=/real-papers,readonly',
        '--mount', f'type=bind,source={directory},target=/run',
        '--workdir', '/src', ORIGINAL, 'python', '-m', 'pytest', '-q', '-p', 'no:cacheprovider', '--junitxml=/run/pytest.xml']
    if options.stage == 'baseline':
        args += ['/tests/test_submission_stability.py']
    else:
        args += ['/tests', '--ignore=/tests/test_layered_d_algorithms.py']
    completed = subprocess.run(args, capture_output=True, timeout=420)
    (directory / 'pytest.stdout.txt').write_bytes(completed.stdout)
    (directory / 'pytest.stderr.txt').write_bytes(completed.stderr)
    save(directory / 'pytest.result.json', {'returncode': completed.returncode, 'args': args})
    counts = {}
    if (directory / 'pytest.xml').exists():
        root = ET.parse(directory / 'pytest.xml').getroot()
        cases = root.findall('.//testcase')
        counts = {'collected': len(cases), 'failed': sum(c.find('failure') is not None or c.find('error') is not None for c in cases),
                  'skipped': sum(c.find('skipped') is not None for c in cases)}
        counts['passed'] = counts['collected'] - counts['failed'] - counts['skipped']
    summary = {'stage': options.stage, 'returncode': completed.returncode, **counts, 'real_model_calls': 0,
               'source_fingerprint': hashlib.sha256(json.dumps(files, sort_keys=True).encode()).hexdigest(),
               'dependency_image_id': image.stdout.decode().strip(), 'source_testing_not_new_image_acceptance': True}
    save(directory / 'summary.json', summary)
    print(completed.stdout.decode('utf-8', errors='replace'))
    print(completed.stderr.decode('utf-8', errors='replace'))
    print(json.dumps({'directory': str(directory), **summary}, ensure_ascii=False))
    raise SystemExit(completed.returncode)

if __name__ == '__main__':
    main()
