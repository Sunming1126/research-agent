"""Offline installed-image fault checks, dispatched by the fixed native coordinator.

The HTTP fixture is synthetic. No provider credentials or real model calls are used.
"""
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import threading
import time
import uuid

import test_agent as T
from main_contract_acceptance import TEAM, create_assignment, frozen, request, save


@contextmanager
def gateway(mode):
    events = []
    finished = threading.Event()

    class Handler(BaseHTTPRequestHandler):
        def do_POST(self):
            self.rfile.read(int(self.headers.get('Content-Length', '0')))
            events.append(dict(time=time.monotonic(), session_header_present=bool(self.headers.get('X-Session-ID'))))
            if mode == 'delay':
                time.sleep(5)
            if mode == 'quota':
                status, value = 429, {'error': {'code': 'AccountQuotaExceeded', 'message': 'Synthetic quota fixture'}}
            else:
                status = 200
                value = dict(id='synthetic-fixture', object='chat.completion', created=0, model='fixture',
                             choices=[dict(index=0, finish_reason='stop', message=dict(role='assistant',
                                 content='invalid JSON' if mode == 'invalid_json' else json.dumps(
                                     dict(answer='Synthetic fixture answer', clarifying_question='What is the scope?'))))],
                             usage=dict(prompt_tokens=10, completion_tokens=10, total_tokens=20))
            body = json.dumps(value).encode()
            try:
                self.send_response(status)
                self.send_header('Content-Type', 'application/json')
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError):
                pass
            finally:
                finished.set()

        def log_message(self, *args):
            pass

    server = ThreadingHTTPServer(('0.0.0.0', 0), Handler)
    worker = threading.Thread(target=server.serve_forever, daemon=True)
    worker.start()
    try:
        yield server.server_address[1], events, finished
    finally:
        server.shutdown()
        server.server_close()


def execute(directory, identity, proof):
    directory.mkdir(parents=True, exist_ok=False)
    rec = T.Recorder(directory)
    for mode in ('delay', 'invalid_json', 'quota'):
        folder = directory / mode
        folder.mkdir()
        output = folder / 'output'
        tasks = frozen()['tasks']
        create_assignment(output, tasks)
        timeout = 10 if mode == 'delay' else 25
        save(folder / 'config.json', dict(case_timeout=timeout, llm_calls=2))
        with gateway(mode) as (gateway_port, events, finished):
            name = 'contract-fault-' + uuid.uuid4().hex[:10]
            port = T.free_port()
            created = False
            try:
                T.docker('run', '-d', '--pull=never', '--name', name, '--read-only',
                         '--cpus', '1', '--memory', '1024m', '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges',
                         '--tmpfs', '/tmp:rw,nosuid,size=128m', '-p', f'127.0.0.1:{port}:8080',
                         '-e', 'PYTHONDONTWRITEBYTECODE=1', '-e', 'AGENTHACK_TELEMETRY_REQUIRED=false',
                         '-e', 'RESEARCH_CONFIG=/fault-config.json', '-e', 'RESEARCH_WORKSPACE_TEAM=' + TEAM,
                         '-e', 'CHALLENGE_SESSION_ID=offline-fault-fixture',
                         '-e', f'CHALLENGE_LLM_BASE_URL=http://host.docker.internal:{gateway_port}/v1',
                         '-e', 'CHALLENGE_LLM_API_KEY=synthetic-fixture-no-real-secret',
                         '-e', 'CHALLENGE_LLM_MODEL=fixture',
                         '--mount', f'type=bind,source={folder / "config.json"},target=/fault-config.json,readonly',
                         '--mount', f'type=bind,source={output},target=/output', identity)
                created = True
                base = f'http://127.0.0.1:{port}'
                for _ in range(60):
                    try:
                        if T.http(base + '/health', timeout=2)[0] == 200:
                            break
                    except (OSError, TimeoutError):
                        pass
                    time.sleep(.3)
                else:
                    raise RuntimeError('Fault-test image failed to start')

                def check():
                    result = request(base, tasks['A-01']['input'], str(uuid.uuid4()))
                    save(folder / 'response.json', result)
                    T.require(result['status'] in (500, 504), 'Fault was presented as a successful answer')
                    T.require('output' not in result['body'], 'SDK error wrapper leaked as an answer')
                    T.require(result['seconds'] <= timeout, 'Whole request exceeded its configured budget')
                    T.require(events and all(e['session_header_present'] for e in events), 'Synthetic gateway never received session-bound requests')
                    T.require(len(events) == (2 if mode == 'invalid_json' else 1), 'Retry bound or quota stop was violated')
                    T.require(finished.wait(7), 'Synthetic request did not finish within its fixed delay')
                    time.sleep(1)
                    T.require(not (output / 'data' / TEAM / 'A-01.json').exists(), 'Cancelled/invalid generation left a late result')
                    T.require(T.http(base + '/health', timeout=2)[0] == 200, 'Image became unhealthy after the fault')
                    return dict(http=result['status'], seconds=result['seconds'], synthetic_requests=len(events),
                                late_result=False, real_model_calls=0)

                rec.test('fault.' + mode, 'installed-image-offline-faults', check)
            finally:
                save(folder / 'synthetic-gateway-events.json', events)
                if created:
                    try:
                        (folder / 'container.log').write_text(T.docker('logs', name), encoding='utf-8')
                    finally:
                        T.docker('rm', '-f', name)
    save(directory / 'summary.json', dict(native_orchestration=proof, real_model_calls=0,
         status='FAIL' if any(row['status'] != 'PASS' for row in rec.rows) else 'PASS', checks=rec.rows))
    return rec
