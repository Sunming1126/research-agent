"""Export only the exact image with completed local acceptance; never submit it."""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
import time
import uuid

import test_agent as T
from main_contract_acceptance import IMAGE, REPO, ROOT, VERSION, save


def sha(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def execute(state, proof, acceptance_run):
    accepted = json.loads((acceptance_run / 'summary.json').read_text(encoding='utf-8'))
    T.require(accepted['status'] == 'LOCAL_ACCEPTANCE_PASSED_PENDING_ARCHIVE', 'Local acceptance is incomplete')
    identity = state['image_id']
    T.require(accepted['image_id'] == identity, 'Acceptance belongs to another image')
    T.require(T.docker('image', 'inspect', IMAGE, '--format', '{{.Id}}') == identity, 'Image tag changed')
    T.require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == state['revision'],
              'Source revision changed after the build')
    T.require(not subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO, text=True).strip(), 'Source checkout is dirty')
    folder = ROOT / '提交材料' / (VERSION + '-' + time.strftime('%Y%m%dT%H%M%S'))
    folder.mkdir(parents=True, exist_ok=False)
    tar = folder / ('research-assistant-' + VERSION + '.tar')
    T.docker('save', '-o', tar, IMAGE, timeout=240)
    T.require(0 < tar.stat().st_size < 2_000_000_000, 'Image archive exceeds the platform size limit')
    with tarfile.open(tar) as archive:
        entries = json.load(archive.extractfile('manifest.json'))
        T.require(len(entries) == 1, 'Archive contains more than the selected image')
        config_bytes = archive.extractfile(entries[0]['Config']).read()
        T.require('sha256:' + hashlib.sha256(config_bytes).hexdigest() == identity, 'Saved archive has another image identity')
        T.require(entries[0].get('RepoTags') == [IMAGE], 'Saved archive lost the selected tag')
    checksum = sha(tar)
    # Re-loading the actual archive checks all Docker archive layers, then match its immutable image identity.
    result = T.docker('load', '-i', tar, timeout=240)
    (folder / 'docker-load.txt').write_text(result + '\n', encoding='utf-8')
    T.require(T.docker('image', 'inspect', IMAGE, '--format', '{{.Id}}') == identity, 'Re-import identity mismatch')
    name = 'contract-archive-' + uuid.uuid4().hex[:10]
    port = T.free_port()
    created = False
    try:
        T.docker('run', '-d', '--pull=never', '--network', 'bridge', '--name', name, '--read-only',
                 '--cpus', '1', '--memory', '1024m', '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges',
                 '--tmpfs', '/tmp:rw,nosuid,size=128m', '-p', f'127.0.0.1:{port}:8080',
                 '-e', 'AGENTHACK_TELEMETRY_REQUIRED=false', '-e', 'PYTHONDONTWRITEBYTECODE=1', identity)
        created = True
        for _ in range(60):
            try:
                code, health = T.http(f'http://127.0.0.1:{port}/health', timeout=2)
                if code == 200:
                    break
            except (OSError, TimeoutError):
                pass
            time.sleep(.3)
        else:
            raise RuntimeError('Fresh imported image failed health verification')
        save(folder / 'fresh-container-health.json', dict(http=code, response=health, image_id=identity))
    finally:
        if created:
            T.docker('rm', '-f', name)
    source = folder / ('source-' + state['revision'][:7] + '.zip')
    subprocess.run(['git', 'archive', '--format=zip', '--output=' + str(source), state['revision']], cwd=REPO, check=True)
    manifest = dict(status='LOCAL_VALIDATED_ARCHIVE', image_id=identity, image_archive=tar.name,
                    image_archive_bytes=tar.stat().st_size, image_archive_sha256=checksum,
                    build_revision=state['revision'], source_archive=source.name, source_archive_sha256=sha(source),
                    source_fingerprint=state['source_fingerprint'], native_orchestration=proof,
                    acceptance_run=str(acceptance_run.relative_to(ROOT)),
                    official_execution='BLOCKED_NO_OFFICIAL_HELPER', official_collector_verified=False,
                    official_score=None, uploaded_to_contest=False)
    save(folder / 'delivery-manifest.json', manifest)
    (folder / 'SHA256SUMS.txt').write_text(checksum + '  ' + tar.name + '\n' + sha(source) + '  ' + source.name + '\n', encoding='utf-8')
    (folder / '提交说明.md').write_text(
        '# 科研助手提交材料\n\n向赛题一主 Agent 上传同目录的 `.tar` 镜像归档。\n\n'
        '本版已完成所附记录中的本地公开验收与归档回读；本地 collector 收到追踪不代表官方已经验收。'
        '本地缺少正式 D helper/来源凭证，未取得官方实验分和榜单分，不能声称覆盖官方私有测试。\n\n'
        f'镜像 ID：`{identity}`。源码提交：`{state["revision"]}`。\n\n'
        '上传后先核对平台登记版本及健康状态，再观察八字段请求、JSON/Markdown 落盘、真实模型计量和官方追踪。'
        '若平台报告失败，保留评测 ID 和逐题错误供下一轮修复。凭据须由正式运行环境注入。\n', encoding='utf-8')
    return manifest, folder
