"""Only a tool in the fixed native Harness conversation may run this coordinator."""
import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent.parent
HERE = ROOT / '镜像测试'
REPO = ROOT / '协同开发/research-agent'
BASELINE = HERE / '审核/2026-10-24-main-64f5efd/source'
SID = 'session-9c903d0e-5884-44fe-bc7f-3719da00864b'
WID = 'c61ec5e8-9932-4ef5-9709-fed302ad7355'
BASE_IMAGE = 'research-assistant:0.4.2-hybrid-v8'
IMAGE = 'research-assistant:0.4.7-contract-20261024'


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def native_proof(stage):
    from native_workspace_harness import workspace, native_rows
    registration = workspace()
    assert SID in registration['sessionIds']
    expected = json.loads((ROOT / '.session-audit/native-main-contract-request.json').read_text(encoding='utf-8'))
    assert expected['session_id'] == SID and expected['workspace_id'] == WID and expected['stage'] == stage
    invocation = None
    for _ in range(30):
        rows, _ = native_rows(SID)
        for row in rows:
            if row.get('type') != 'assistant/message' or row.get('seq', 0) <= expected['before_seq']:
                continue
            for part in row.get('data', {}).get('message', {}).get('content', []):
                if part.get('type') == 'tool-call':
                    command = json.dumps(part, ensure_ascii=False)
                    if 'native_main_contract_run.py' in command and '--stage ' + stage in command:
                        invocation = part
        if invocation:
            break
        time.sleep(.2)
    if invocation is None:
        raise RuntimeError('No new native tool invocation in the required conversation; execution refused')
    os.environ['ANIC_NATIVE_ORCHESTRATOR_SESSION_ID'] = SID
    return dict(native_tool_execution_verified=True, workspace_id=WID, session_id=SID,
                tool_sha256=hashlib.sha256(json.dumps(invocation, sort_keys=True).encode()).hexdigest(),
                new_workspace_created=False, new_conversation_created=False)


def run(args, directory, label, timeout=240):
    try:
        completed = subprocess.run(list(map(str, args)), capture_output=True, timeout=timeout,
                                   creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    except subprocess.TimeoutExpired as exc:
        (directory / (label + '.stdout.txt')).write_bytes(exc.stdout or b'')
        (directory / (label + '.stderr.txt')).write_bytes(exc.stderr or b'')
        save(directory / (label + '.result.json'), dict(status='TIMEOUT', timeout_seconds=timeout))
        raise
    (directory / (label + '.stdout.txt')).write_bytes(completed.stdout)
    (directory / (label + '.stderr.txt')).write_bytes(completed.stderr)
    save(directory / (label + '.result.json'), dict(returncode=completed.returncode,
         status='PASS' if completed.returncode == 0 else 'FAIL', args=list(map(str, args))))
    print(completed.stdout.decode('utf-8', errors='replace'), flush=True)
    print(completed.stderr.decode('utf-8', errors='replace'), flush=True)
    return completed.returncode


def fingerprint(source):
    paths = [source / name for name in ('agent.py', 'Dockerfile', 'requirements.txt', '.dockerignore')]
    paths += [path for section in ('src', 'tests', 'evaluation') for path in (source / section).rglob('*.py')
              if '__pycache__' not in path.parts]
    rows = {path.relative_to(source).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths if path.is_file()}
    return hashlib.sha256(json.dumps(rows, sort_keys=True).encode()).hexdigest(), rows


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage', choices=['syntax', 'baseline', 'regression', 'build', 'acceptance', 'archive'], required=True)
    options = parser.parse_args()
    proof = native_proof(options.stage)
    os.environ['PATH'] = str(Path.home() / 'AppData/Local/Programs/DockerDesktop/resources/bin') + os.pathsep + os.environ.get('PATH', '')
    if options.stage == 'syntax':
        directory = HERE / 'runs' / ('main-contract-047-syntax-' + time.strftime('%Y%m%dT%H%M%S'))
        directory.mkdir(parents=True, exist_ok=False)
        checksum, files = fingerprint(REPO)
        errors = []
        for name in files:
            if name.endswith('.py'):
                try:
                    ast.parse((REPO / name).read_text(encoding='utf-8-sig'), filename=name, feature_version=(3, 11))
                except SyntaxError as exc:
                    errors.append(dict(file=name, line=exc.lineno, error=exc.msg))
        save(directory / 'native-orchestration-proof.json', proof)
        save(directory / 'source-files.json', files)
        save(directory / 'summary.json', dict(stage='syntax', source_fingerprint=checksum, errors=errors,
             parsed_python_files=sum(name.endswith('.py') for name in files), real_model_calls=0,
             functional_tests_run=0, status='FAIL' if errors else 'PASS'))
        print(json.dumps(dict(directory=str(directory), errors=errors), ensure_ascii=False), flush=True)
        if errors:
            raise SystemExit(1)
        return
    # An approval refusal must occur before allocating a run, and must not overwrite evidence.
    for attempt in range(18):
        check = subprocess.run(['docker', 'image', 'inspect', BASE_IMAGE, '--format', '{{.Id}}'], capture_output=True,
                               timeout=25, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        if not check.returncode:
            break
        print('Waiting for the existing Docker engine: attempt ' + str(attempt + 1), flush=True)
        time.sleep(5)
    if check.returncode:
        raise RuntimeError('Docker unavailable: ' + check.stderr.decode('utf-8', errors='replace')[-1000:])
    stamp = time.strftime('%Y%m%dT%H%M%S')
    destination = HERE / 'runs' / ('main-contract-047-' + options.stage + '-' + stamp)
    destination.mkdir(parents=True, exist_ok=False)
    save(destination / 'native-orchestration-proof.json', proof)
    toolkit_names = ['native_main_contract_run.py', 'main_contract_acceptance.py', 'main_contract_paper_audit.py', 'main_contract_faults.py', 'main_contract_archive.py',
                     'test_agent.py', 'compare_images.py', 'magic_api_bridge.py', 'read_magic_connection.cjs', 'public_oracles.py']
    save(destination / 'toolkit.json', dict(source_hashes={name: hashlib.sha256((HERE / name).read_bytes()).hexdigest()
                                                        for name in toolkit_names},
                                           sdk_reference_image_id=check.stdout.decode().strip()))
    save(ROOT / ('.session-audit/native-main-contract-' + options.stage + '-latest.json'), dict(run=str(destination)))
    if options.stage in {'baseline', 'regression'}:
        source = BASELINE if options.stage == 'baseline' else REPO
        source_checksum, source_files = fingerprint(source)
        save(destination / 'source-files.json', source_files)
        dependencies = REPO / 'output/test-deps'
        command = ['docker', 'run', '--rm', '--pull=never', '--network', 'none', '--read-only',
                   '--cpus', '1', '--memory', '1024m', '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges',
                   '--tmpfs', '/tmp:rw,nosuid,size=256m', '-e', 'PYTHONDONTWRITEBYTECODE=1',
                   '-e', 'PYTHONPATH=/deps:/src:/src/src:/src/tests', '-e', 'RESEARCH_RUNTIME=local',
                   '-e', 'AGENTHACK_TELEMETRY_REQUIRED=false',
                   '--mount', f'type=bind,source={source},target=/src,readonly',
                   '--mount', f'type=bind,source={dependencies},target=/deps,readonly',
                   '--mount', f'type=bind,source={destination},target=/results', '--workdir', '/src']
        if options.stage == 'baseline':
            probes = HERE / '审核/2026-10-24-main-64f5efd/contract-probes'
            command += ['--mount', f'type=bind,source={probes},target=/contract-probes,readonly']
            suites = ['/contract-probes']
        else:
            materials = ROOT / '测试输入/最新要求-20261020'
            command += ['-e', 'PUBLIC_EXPERIMENT_ROOT=/materials', '--mount', f'type=bind,source={materials},target=/materials,readonly']
            suites = ['/src/tests', '/src/evaluation']
        command += ['--entrypoint', 'python', BASE_IMAGE, '-m', 'pytest', *suites, '-q', '--tb=short',
                    '-p', 'no:cacheprovider', '--junitxml=/results/pytest.xml']
        result = run(command, destination, 'pytest', timeout=300)
        save(destination / 'summary.json', dict(stage=options.stage, returncode=result, tests_passed=result == 0,
             source_fingerprint=source_checksum,
             real_model_calls=0, note='Baseline failures are retained; no outcome is reclassified.'))
        if result:
            raise SystemExit(result)
    elif options.stage == 'build':
        previous = json.loads((ROOT / '.session-audit/native-main-contract-regression-latest.json').read_text(encoding='utf-8'))
        result = json.loads((Path(previous['run']) / 'summary.json').read_text(encoding='utf-8'))
        source_checksum, source_files = fingerprint(REPO)
        if not result['tests_passed'] or result['source_fingerprint'] != source_checksum:
            raise RuntimeError('Current source must pass regression before building')
        revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
        if subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO, text=True).strip():
            raise RuntimeError('Commit the reviewed candidate before freezing its image')
        save(destination / 'source-files.json', source_files)
        result = run(['docker', 'build', '--pull=false', '--label', 'org.opencontainers.image.revision=' + revision,
                      '-t', IMAGE, str(REPO)], destination, 'build', timeout=600)
        if result:
            raise SystemExit(result)
        info = json.loads(subprocess.check_output(['docker', 'image', 'inspect', IMAGE]))[0]
        sensitive = {item.split('=', 1)[0]: bool(item.split('=', 1)[1]) for item in info['Config'].get('Env', [])
                     if item.split('=', 1)[0] != 'GPG_KEY' and any(word in item.split('=', 1)[0].upper() for word in ('KEY', 'SECRET', 'TOKEN', 'PASSWORD'))}
        if any(sensitive.values()):
            raise RuntimeError('Candidate image contains a nonempty credential environment variable')
        if info['Os'] != 'linux' or info['Architecture'] != 'amd64' or info['Config']['User'] in ('', 'root', '0'):
            raise RuntimeError('Candidate image architecture/user invalid')
        state = dict(status='BUILT_PENDING_ACCEPTANCE', image_id=info['Id'], tag=IMAGE, revision=revision,
                     source_fingerprint=source_checksum, nonempty_credential_environment=sensitive,
                     platform='linux/amd64', user=info['Config']['User'], ready_to_submit=False)
        save(destination / 'summary.json', state)
        save(ROOT / '.session-audit/native-main-contract-candidate-image.json', state)
        print(json.dumps(state, ensure_ascii=False), flush=True)
    elif options.stage == 'acceptance':
        state = json.loads((ROOT / '.session-audit/native-main-contract-candidate-image.json').read_text(encoding='utf-8'))
        if state['source_fingerprint'] != fingerprint(REPO)[0]:
            raise RuntimeError('Source changed since build; rerun regression/build')
        actual = subprocess.check_output(['docker', 'image', 'inspect', IMAGE, '--format', '{{.Id}}'], text=True).strip()
        if actual != state['image_id']:
            raise RuntimeError('Image tag changed since build')
        from main_contract_faults import execute as execute_faults
        faults = execute_faults(destination / 'offline-faults', actual, proof)
        if any(row['status'] != 'PASS' for row in faults.rows):
            raise RuntimeError('Installed-image fault checks failed; no real provider call started')
        from main_contract_acceptance import execute
        first = destination / 'main'
        first.mkdir()
        primary = execute(first, proof)
        if any(row['status'] == 'FAIL' for row in primary.rows):
            raise RuntimeError('Installed-image acceptance failed; original evidence retained')
        second = destination / 'independent-d-repeat'
        second.mkdir()
        repeated = execute(second, proof, repeat=True)
        if any(row['status'] in {'FAIL', 'BLOCKED'} for row in repeated.rows):
            raise RuntimeError('Independent D generation did not pass all local checks')
        save(destination / 'summary.json', dict(status='LOCAL_ACCEPTANCE_PASSED_PENDING_ARCHIVE',
             image_id=actual, main_run=str(first), independent_d_run=str(second),
             official_execution='BLOCKED_NO_OFFICIAL_HELPER', official_score=None, uploaded_to_contest=False))
    elif options.stage == 'archive':
        state = json.loads((ROOT / '.session-audit/native-main-contract-candidate-image.json').read_text(encoding='utf-8'))
        if state['source_fingerprint'] != fingerprint(REPO)[0]:
            raise RuntimeError('Source changed since build; repeat validation')
        previous = json.loads((ROOT / '.session-audit/native-main-contract-acceptance-latest.json').read_text(encoding='utf-8'))
        from main_contract_archive import execute as export
        manifest, folder = export(state, proof, Path(previous['run']))
        save(destination / 'summary.json', dict(manifest, delivery_directory=str(folder)))


if __name__ == '__main__':
    main()
