"""Independent literal quote/page audit; runs offline inside a dependency image."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import unicodedata

import fitz

OUTPUT = Path('/output')
PAPERS = Path('/papers')
TEAM = '最初一舞'


def canonical(text):
    return ''.join(char for char in unicodedata.normalize('NFKC', text).casefold() if char.isalnum())


def audit():
    results = []
    for case_id in ('C-01', 'C-03', 'E-01', 'E-02'):
        assigned = json.loads((OUTPUT / 'data' / TEAM / 'assigned' / (case_id + '.json')).read_text(encoding='utf-8'))
        records = list((OUTPUT / 'data' / TEAM / 'work' / case_id).glob('*/evidence.json'))
        if len(records) != 1:
            raise AssertionError('No unique report evidence ledger: ' + case_id)
        evidence = json.loads(records[0].read_text(encoding='utf-8'))
        claims = evidence['claims']
        if not claims:
            raise AssertionError('No source evidence: ' + case_id)
        row = dict(case_id=case_id, quotes_checked=0, papers={}, verification_modes=dict(Counter(e.get('verification') for e in claims)))
        for name in sorted({item['filename'] for item in claims}):
            if name not in assigned['materials'] or Path(name).name != name:
                raise AssertionError('Unauthorized PDF ledger entry')
            source = PAPERS / name
            row['papers'][name] = hashlib.sha256(source.read_bytes()).hexdigest()
            with fitz.open(source) as document:
                cached = {}
                for item in (e for e in claims if e['filename'] == name):
                    page_number = item['page']
                    if type(page_number) is not int or not 1 <= page_number <= len(document):
                        raise AssertionError('Invalid physical PDF page')
                    needle = canonical(item['quote'])
                    if len(needle) < 12:
                        raise AssertionError('Quote too short for independent verification')
                    if page_number not in cached:
                        page = document[page_number - 1]
                        texts = [canonical(page.get_text('text'))]
                        texts += [canonical(block[4]) for block in page.get_text('blocks') if isinstance(block[4], str)]
                        try:
                            for table in page.find_tables().tables:
                                texts += [canonical(' '.join(str(cell or '') for cell in cells)) for cells in table.extract()]
                        except (AttributeError, RuntimeError, ValueError):
                            pass
                        cached[page_number] = texts
                    if not any(needle in text for text in cached[page_number]):
                        raise AssertionError('Quote does not match its authorized PDF/page: ' + name + ':' + str(page_number))
                    row['quotes_checked'] += 1
        results.append(row)
    Path('/results/paper-quote-audit.json').write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(dict(reports=len(results), source_quotes=sum(row['quotes_checked'] for row in results),
                         scope='literal source and page verification; not an expert factual score')))


if __name__ == '__main__':
    audit()
