"""Installed-image checks with independent wire/artifact assertions and real magic calls.

Invoked only after native_main_contract_run verifies the fixed native conversation.
No private scoring data, provider keys, or reference algorithms enter the image.
"""
from collections import Counter
from contextlib import contextmanager
import gzip
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import re
import threading
import time
import urllib.error
import urllib.request
import uuid

import test_agent as T
import compare_images as C
from magic_api_bridge import HarnessBridge

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / '协同开发/research-agent'
TEAM = '最初一舞'
VERSION = '0.4.7-contract-20261024'
IMAGE = 'research-assistant:' + VERSION
FIELDS = dict(Chat={'case_id', 'answer', 'clarifying_question'},
              Literature_Retrieval={'case_id', 'papers'}, Survey={'case_id', 'path', 'markdown'},
              Idea={'case_id', 'path', 'markdown'}, Reproduction={'case_id', 'status', 'metrics', 'figures'})


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def request(base, payload, task_id, *, raw=None):
    body = raw if raw is not None else json.dumps(payload, ensure_ascii=False).encode()
    req = urllib.request.Request(base + '/solve', data=body, headers={
        'Content-Type': 'application/json', 'X-Research-Task-ID': task_id,
        'Idempotency-Key': task_id, 'X-Challenge-Protocol': 'research-assistant.v1'})
    started = time.monotonic()
    try:
        response = urllib.request.urlopen(req, timeout=185)
    except urllib.error.HTTPError as exc:
        response = exc
    with response:
        status, raw_body, headers = response.code, response.read(), dict(response.headers.items())
    return dict(status=status, body=json.loads(raw_body), headers=headers, seconds=time.monotonic() - started)


def frozen():
    inputs = json.loads(json.dumps(C.frozen_inputs()))
    corrected = json.loads((C.BASE / 'corrected-C-02-input.json').read_text(encoding='utf-8'))
    corrected['input']['case_id'] = 'C-03'
    inputs['tasks'].pop('C-02')
    inputs['tasks']['C-03'] = corrected
    return inputs


def create_assignment(output, tasks):
    base = output / 'data' / TEAM
    (base / 'assigned').mkdir(parents=True, exist_ok=True)
    rows = []
    for case_id, task in sorted(tasks.items()):
        question = task['input']
        raw = json.dumps(question, ensure_ascii=False, indent=2).encode('utf-8')
        (base / 'assigned' / (case_id + '.json')).write_bytes(raw)
        row = dict(case_id=case_id, function=question['function'], title=question['title'],
                   question_file=f'data/{TEAM}/assigned/{case_id}.json', question_sha256=hashlib.sha256(raw).hexdigest())
        if case_id.startswith('D-'):
            row['difficulty'] = 'medium'
        rows.append(row)
    save(base / 'dispatch.json', dict(team=TEAM, schema_version=3, rules_version='research-assistant-objective-v3',
         case_ids=sorted(tasks), cases_per_category=dict(zip('ABCDE', [1, 3, 2, 3, 2])), cases=rows))


def independent_answer(case, response, output):
    T.require(response['status'] == 200, 'Solve HTTP status ' + str(response['status']))
    value = response['body']
    T.require(isinstance(value, dict) and set(value) == FIELDS[case['function']], 'Wire schema mismatch')
    T.require(value['case_id'] == case['case_id'], 'Wrong case identity')
    stored = output / 'data' / TEAM / (case['case_id'] + '.json')
    T.require(stored.is_file() and json.loads(stored.read_text(encoding='utf-8')) == value, 'HTTP/disk JSON mismatch')
    T.require(response['seconds'] <= 180, 'End-to-end deadline exceeded')
    if case['function'] == 'Chat':
        T.require(all(isinstance(value[k], str) and value[k].strip() for k in ('answer', 'clarifying_question')), 'Empty answer')
    elif case['function'] == 'Literature_Retrieval':
        names = []
        for paper in value['papers']:
            T.require(set(paper) == {'filename', 'reason'} and paper['reason'].strip(), 'Invalid retrieval row')
            T.require(Path(paper['filename']).name == paper['filename'] and '\\' not in paper['filename'], 'Retrieval returned a path instead of a filename')
            whole_library = any(''.join(item.split()) in {'本地论文文件夹内的PDF', '论文库', 'papers', 'data/论文库', 'data/papers'}
                                for item in case['materials'])
            T.require(paper['filename'] in case['materials'] or whole_library,
                      'Unauthorized retrieval filename')
            T.require((T.SHARE / 'papers' / paper['filename']).is_file(), 'Unknown PDF')
            names.append(paper['filename'])
        T.require(len(names) == len(set(names)), 'Repeated paper')
    elif case['function'] in ('Survey', 'Idea'):
        markdown = value['markdown']
        T.require(markdown.count('## 参考文献') == 1, 'Missing/duplicate reference section')
        body, references = markdown.split('## 参考文献')
        T.require(len(re.sub(r'\s', '', body)) >= 800, 'Report too short')
        T.require(len(body) <= (4500 if case['function'] == 'Survey' else 6000), 'Report over character limit')
        found = [ref for match in re.finditer(r'\[(\d{1,2}(?:\s*,\s*\d{1,2})*)(?:,\s*p\.\s*\d+)?\]', body)
                 for ref in re.split(r'\s*,\s*', match.group(1))]
        if case['function'] == 'Survey':
            T.require(len(found) <= 40, 'Survey exceeds 40 citation instances')
        refs = re.findall(r'^\[(\d+)\]\s+(.+\.pdf)\s*$', references, re.M)
        T.require(set(found) == {ref for ref, _ in refs}, 'Citation/reference identity mismatch')
        T.require(len({name for _, name in refs}) >= (5 if case['function'] == 'Survey' else 1), 'Insufficient papers')
        T.require({name for _, name in refs} <= set(case['materials']), 'Report used an unauthorized PDF')
        kind = '综述' if case['function'] == 'Survey' else '灵感Idea报告'
        T.require(value['path'] == f"data/expert/{case['case_id']}-{kind}-{TEAM}.md", 'Wrong team/report path')
        T.require((output / value['path']).read_text(encoding='utf-8') == markdown, 'Markdown differs from JSON')
    else:
        T.require(value['status'] in ('completed', 'failed', 'materials_missing'), 'Unknown D status')
        T.require(isinstance(value['metrics'], list) and len(value['metrics']) == 3, 'D needs exactly three metrics')
        T.require(value['status'] != 'completed', 'No official helper exists locally; completed would be fabricated')
        for metric in value['metrics']:
            T.require(set(metric) == {'name', 'unit', 'reference', 'observed', 'relative_error'}, 'Wrong metric fields')
            T.require(metric['observed'] is None and metric['relative_error'] is None,
                      'Unavailable formal result claimed a measurement or relative error')
    headers = {k.lower(): v for k, v in response['headers'].items()}
    T.require(re.fullmatch('[0-9a-f]{32}', headers.get('x-agenthack-trace-id', '')), 'No actual SDK trace id')
    return dict(case_id=case['case_id'], seconds=round(response['seconds'], 3), status=value.get('status', 'answered'),
                trace_id=headers['x-agenthack-trace-id'], result_sha256=hashlib.sha256(stored.read_bytes()).hexdigest())


@contextmanager
def collector(directory):
    packets = directory / 'otlp'
    packets.mkdir()
    counter = []
    class Handler(BaseHTTPRequestHandler):
        def do_POST(self):
            data = self.rfile.read(int(self.headers.get('Content-Length', '0')))
            if self.headers.get('Content-Encoding') == 'gzip':
                data = gzip.decompress(data)
            target = packets / (uuid.uuid4().hex + '.bin')
            target.write_bytes(data)
            counter.append(target.name)
            self.send_response(200)
            self.send_header('Content-Type', 'application/x-protobuf')
            self.send_header('Content-Length', '0')
            self.end_headers()
        def log_message(self, *args):
            pass
    server = ThreadingHTTPServer(('0.0.0.0', 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield server.server_address[1], counter
    finally:
        server.shutdown()
        server.server_close()


def image_audit(rec, identity):
    program = """import pathlib,hashlib,json,agenthack
from agenthack import AgentRuntime
root=pathlib.Path('/app'); paths=[root/'agent.py',*root.glob('src/**/*.py')]
sdk=pathlib.Path(agenthack.__file__).parent
print(json.dumps({'files':{p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
'sdk_files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sdk.glob('*.py')},
'sdk_version':agenthack.__version__,'runtime_module':AgentRuntime.__module__}))"""
    actual = json.loads(T.docker('run', '--rm', '--pull=never', '--network', 'none', '--read-only',
                                '-e', 'PYTHONDONTWRITEBYTECODE=1', '--entrypoint', 'python', identity, '-c', program))
    expected_paths = [REPO / 'agent.py', *[p for p in (REPO / 'src').rglob('*.py') if 'd_algorithms' not in p.parts]]
    expected = {p.relative_to(REPO).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in expected_paths}
    save(rec.root / 'installed-source.json', actual)
    T.require(actual['files'] == expected, 'Installed image source differs from the frozen checkout')
    T.require(actual['sdk_version'] == '1.1.1' and actual['runtime_module'] == 'agenthack.runtime', 'Unexpected SDK/runtime')
    reference = ROOT / '镜像测试/审核/2026-10-24-main-7ceaaa2/evidence/sdk-reference-from-v8'
    for path in reference.glob('*.py'):
        T.require(actual['sdk_files'].get(path.name) == hashlib.sha256(path.read_bytes()).hexdigest(),
                  'Official SDK file changed: ' + path.name)
    return dict(source_files=len(expected), sdk=actual['sdk_version'])


def input_integrity():
    package = json.loads((T.MATERIAL / 'PACKAGE_MANIFEST.json').read_text(encoding='utf-8'))
    material_files = 0
    for name, entry in package['files'].items():
        target = (T.MATERIAL / name).resolve()
        T.require(target.is_relative_to(T.MATERIAL.resolve()), 'Public material manifest escapes its root')
        T.require(target.is_file() and hashlib.sha256(target.read_bytes()).hexdigest() == entry['sha256'],
                  'Public experiment input hash mismatch')
        material_files += 1
    papers = {}
    for line in (T.SHARE / 'SHA256SUMS.txt').read_text(encoding='utf-8-sig').splitlines():
        match = re.fullmatch(r'([0-9a-fA-F]{64})\s+\*?(.+)', line.strip())
        if not match:
            continue
        name = match[2].replace('\\', '/').removeprefix('team_share/').removeprefix('./')
        if not name.startswith('papers/'):
            continue
        target = (T.SHARE / name).resolve()
        T.require(target.is_relative_to((T.SHARE / 'papers').resolve()), 'Paper manifest path escapes its root')
        actual = hashlib.sha256(target.read_bytes()).hexdigest()
        T.require(actual == match[1].lower(), 'Frozen public PDF hash mismatch')
        papers[target.name] = actual
    T.require(len(papers) >= 7, 'Seven approved public test PDFs are required')
    return dict(public_material_files=material_files, paper_hashes=papers)


def verify_collector(rec, identity, responses, session_id):
    program = """import json,pathlib
from opentelemetry.proto.collector.trace.v1.trace_service_pb2 import ExportTraceServiceRequest
rows=[]
keys={'task_id','session_id','task_type','success','llm_call_count','total_input_tokens','total_output_tokens','model','error_type'}
for path in pathlib.Path('/results/otlp').glob('*.bin'):
 request=ExportTraceServiceRequest();request.ParseFromString(path.read_bytes())
 for resource in request.resource_spans:
  for scope in resource.scope_spans:
   for span in scope.spans:
    attrs={}
    for attr in span.attributes:
     if attr.key in keys:
      kind=attr.value.WhichOneof('value');attrs[attr.key]=getattr(attr.value,kind)
    rows.append(dict(name=span.name,trace_id=span.trace_id.hex(),span_id=span.span_id.hex(),parent_span_id=span.parent_span_id.hex(),attributes=attrs))
pathlib.Path('/results/otlp-decoded.json').write_text(json.dumps(rows,ensure_ascii=False),encoding='utf-8')
print(json.dumps({'actual_spans':len(rows)}))"""
    T.docker('run', '--rm', '--pull=never', '--network', 'none', '--read-only',
             '--mount', f'type=bind,source={rec.root},target=/results', '--entrypoint', 'python', identity, '-c', program)
    rows = json.loads((rec.root / 'otlp-decoded.json').read_text(encoding='utf-8'))
    for response in responses:
        matching = [row for row in rows if row['trace_id'] == response['trace_id']]
        roots = [row for row in matching if row['name'] == 'agent.session']
        T.require(len(roots) == 1, 'Missing/duplicate root session: ' + response['case_id'])
        root = roots[0]
        T.require(root['attributes'].get('task_id') == response['task_id'], 'Wrong transport task in actual trace')
        T.require(root['attributes'].get('session_id') == session_id, 'Wrong challenge session in actual trace')
        graph = {row['span_id']: row['parent_span_id'] for row in matching}
        llms = [row for row in matching if 'llm' in row['name'].lower()]
        T.require(llms, 'No actual model span for a live case')
        for row in llms:
            seen, parent = set(), row['parent_span_id']
            while parent in graph and parent != root['span_id'] and parent not in seen:
                seen.add(parent)
                parent = graph[parent]
            T.require(parent == root['span_id'], 'Model span is not a descendant of its task session')
    return dict(actual_spans=len(rows), bound_case_traces=len(responses), scope='local collector; not official receipt')


def current_model_source(output, cid):
    sources = list((output / 'data' / TEAM / 'work' / cid).glob('*/implementation.py'))
    T.require(len(sources) == 1, 'No unique current-case model source')
    source = sources[0]
    generation = json.loads((source.parent / 'generation-response.json').read_text(encoding='utf-8'))
    reply = generation['choices'][0]['message']['content']
    candidates = [reply, *re.findall(r'^```(?:python|py)?[ \t]*\r?\n(.*?)^```[ \t]*$', reply, re.M | re.S)]
    normalize = lambda value: value.replace('\r\n', '\n').replace('\r', '\n').rstrip('\n')
    T.require(any(normalize(value) == normalize(source.read_text(encoding='utf-8')) for value in candidates),
              'Source was edited after the model reply')
    history = json.loads((source.parent / 'public-selftest.json').read_text(encoding='utf-8'))['attempts']
    T.require(history and history[-1].get('status') == 'passed', 'Final public self-test did not pass')
    T.require(history[-1]['source_sha256'] == hashlib.sha256(source.read_bytes()).hexdigest(), 'Self-test source identity mismatch')
    return source


def independent_paper_audit(rec, identity, output):
    text = T.docker('run', '--rm', '--pull=never', '--network', 'none', '--read-only',
                    '--cpus', '1', '--memory', '1024m', '-e', 'PYTHONDONTWRITEBYTECODE=1',
                    '--mount', f'type=bind,source={ROOT / "镜像测试"},target=/testkit,readonly',
                    '--mount', f'type=bind,source={T.SHARE / "papers"},target=/papers,readonly',
                    '--mount', f'type=bind,source={output},target=/output,readonly',
                    '--mount', f'type=bind,source={rec.root},target=/results',
                    '--entrypoint', 'python', identity, '/testkit/main_contract_paper_audit.py', timeout=90)
    return json.loads(text)


def execute(directory, proof, *, repeat=False):
    os.environ['TEST_HARNESS_REASONING'] = 'off'
    inputs = frozen()
    tasks = inputs['tasks']
    save(directory / 'frozen-inputs.json', inputs)
    rec = T.Recorder(directory)
    checked = rec.test('inputs.frozen_public_material_hashes', 'input-integrity', input_integrity)
    if checked['status'] != 'PASS':
        raise RuntimeError('Public test inputs failed integrity checks; no provider call started')
    info = json.loads(T.docker('image', 'inspect', IMAGE))[0]
    identity = info['Id']
    T.IMAGE = identity
    save(directory / 'image-identity.json', dict(image_id=identity, tag=IMAGE, labels=info['Config']['Labels']))
    installed = rec.test('image.installed_source', 'image-integrity', lambda: image_audit(rec, identity))
    if installed['status'] != 'PASS':
        raise RuntimeError('Installed source/SDK mismatch; no provider call started')
    output = directory / 'output'
    output.mkdir()
    create_assignment(output, tasks)
    session_id = 'contract-047-' + uuid.uuid4().hex
    cases = ['D-01', 'D-02', 'D-05'] if repeat else ['A-01', 'B-01', 'B-02', 'B-03', 'C-01', 'C-03', 'E-01', 'E-02', 'D-01', 'D-02', 'D-05']
    responses = []
    with HarnessBridge(directory / 'model-calls') as bridge, collector(directory) as (collector_port, packets):
        base_handler = bridge.server.RequestHandlerClass
        class SessionCheckedHandler(base_handler):
            def do_POST(self):
                if self.headers.get('X-Session-ID') != session_id:
                    return self.send(400, {'error': {'message': 'Missing/wrong challenge session header'}})
                return super().do_POST()
        bridge.server.RequestHandlerClass = SessionCheckedHandler
        port = T.free_port()
        name = 'main-contract-047-' + uuid.uuid4().hex[:10]
        args = ['run', '-d', '--pull=never', '--name', name, '--read-only', '--cpus', '1', '--memory', '1024m',
                '--pids-limit', '128', '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges',
                '--tmpfs', '/tmp:rw,nosuid,size=256m', '-p', f'127.0.0.1:{port}:8080',
                '-e', 'PYTHONDONTWRITEBYTECODE=1', '-e', 'RESEARCH_WORKSPACE_TEAM=' + TEAM,
                '-e', 'CHALLENGE_SESSION_ID=' + session_id, '-e', 'TEAM_ID=local-telemetry-test',
                '-e', f'CHALLENGE_LLM_BASE_URL=http://host.docker.internal:{bridge.port}/session/{session_id}/v1',
                '-e', 'CHALLENGE_LLM_API_KEY=' + bridge.token, '-e', 'CHALLENGE_LLM_MODEL=harness-magic',
                '-e', 'RESEARCH_LLM_THINKING=disabled', '-e', 'AGENTHACK_TELEMETRY_REQUIRED=true',
                '-e', 'AGENTHACK_FLUSH_ON_SOLVE=true', '-e', f'OTEL_EXPORTER_OTLP_TRACES_ENDPOINT=http://host.docker.internal:{collector_port}/v1/traces',
                '-e', 'RESEARCH_LAYERED_D=layered-d-v3', '-e', 'RESEARCH_D_SOURCE_PROVENANCE=d-model-source-v1',
                '--mount', f'type=bind,source={T.SHARE / "papers"},target=/data/papers,readonly',
                '--mount', f'type=bind,source={T.MATERIAL},target=/data/experiments,readonly',
                '--mount', f'type=bind,source={output},target=/output']
        created = False
        try:
            T.docker(*args, identity)
            created = True
            base = f'http://127.0.0.1:{port}'
            for _ in range(60):
                try:
                    status, health = T.http(base + '/health', timeout=2)
                    if status == 200:
                        break
                except (OSError, TimeoutError):
                    pass
                time.sleep(.4)
            else:
                raise RuntimeError('Image did not become healthy')
            save(directory / 'health.json', health)
            for cid in cases:
                before = len(bridge.records)
                case = tasks[cid]['input']
                task_id = str(uuid.uuid4())
                def check(cid=cid, case=case, task_id=task_id):
                    response = request(base, case, task_id)
                    save(directory / 'responses' / (cid + '.json'), dict(task_id=task_id, request=case, **response))
                    result = independent_answer(case, response, output)
                    T.require(len(bridge.records) > before, 'No real model reply from this case')
                    result['task_id'] = task_id
                    responses.append(result)
                    if cid.startswith('B-'):
                        T.require({p['filename'] for p in response['body']['papers']} == set(inputs['retrieval_expected'][cid]),
                                  'Public retrieval expected set differs')
                    return result
                rec.test('live.' + cid + '.wire_artifacts', 'real-model-cases', check)
                if cid.startswith('D-'):
                    source_box = {}
                    def provenance(cid=cid):
                        source_box['path'] = current_model_source(output, cid)
                        return dict(sha256=hashlib.sha256(source_box['path'].read_bytes()).hexdigest())
                    rec.test('source.' + cid + '.model_reply_identity', 'D-source-provenance', provenance)
                    if 'path' in source_box:
                        T.public_samples(rec, cid, source_box['path'])
                    else:
                        rec.add('public_algorithm.' + cid, 'D-public-algorithm', 'BLOCKED', error='No unique accepted model source')
            if not repeat:
                for label, payload, raw in [('assigned_request_tamper', dict(tasks['A-01']['input'], input='Unassigned question'), None),
                                            ('invalid_eight_fields', dict(tasks['A-01']['input'], extra='forbidden'), None),
                                            ('malformed_json', None, b'{"input":')]:
                    before = len(bridge.records)
                    def reject(label=label, payload=payload, raw=raw):
                        response = request(base, payload, str(uuid.uuid4()), raw=raw)
                        save(directory / 'negative' / (label + '.json'), response)
                        T.require(response['status'] >= 400 and len(bridge.records) == before,
                                  'Invalid request reached a model or appeared successful')
                        return dict(http=response['status'], real_model_calls=0)
                    rec.test('negative.' + label, 'authorization', reject)
            rec.test('telemetry.otlp_packets_received', 'local-collector', lambda: T.require(bool(packets), 'No actual OTLP packets'))
        finally:
            if created:
                (directory / 'container.log').write_text(T.docker('logs', name), encoding='utf-8')
                T.docker('rm', '-f', name)
    save(directory / 'response-traces.json', responses)
    rec.test('telemetry.actual_trace_correlations', 'local-collector',
             lambda: verify_collector(rec, identity, responses, session_id))
    if not repeat:
        rec.test('reports.independent_pdf_page_quote_audit', 'report-evidence',
                 lambda: independent_paper_audit(rec, identity, output))
    save(directory / 'summary.json', dict(image_id=identity, counts=dict(Counter(row['status'] for row in rec.rows)),
         native_orchestration=proof, official_execution='BLOCKED_NO_OFFICIAL_HELPER', official_score=None,
         official_collector_verified=False, independent_repeat=repeat,
         mandatory_failures=[row['id'] for row in rec.rows if row['status'] == 'FAIL'],
         model_attempts=len(list((directory / 'model-calls').glob('*/call.json'))),
         model_replies_recorded=len(bridge.records)))
    return rec
