"""Submit one explicit test job in the visually verified existing main conversation."""
import argparse
import ctypes
import json
import sys
import time
from ctypes import wintypes
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / '镜像测试'))
from native_workspace_harness import workspace, native_rows, selection, EXPECTED_ID
from harness_window import focus, point, chord, type_text, window, user32

parser = argparse.ArgumentParser()
parser.add_argument('--stage', choices=['syntax', 'baseline', 'regression', 'build', 'acceptance', 'archive'], required=True)
options = parser.parse_args()
saved = json.loads((ROOT / '.session-audit/native-api-main-conversation.json').read_text(encoding='utf-8'))
assert saved['workspace_id'] == EXPECTED_ID and saved['session_id'] in workspace()['sessionIds']
selection()
try:
    focus()
except RuntimeError:
    user32.SwitchToThisWindow.argtypes = [ctypes.c_void_p, ctypes.c_int]
    user32.SwitchToThisWindow(window(), 1)
    time.sleep(.3)
    focus()
rect = wintypes.RECT()
user32.GetWindowRect(window(), ctypes.byref(rect))
assert (rect.right - rect.left, rect.bottom - rect.top) == (1941, 1243)
rows, _ = native_rows(saved['session_id'])
before = max((r.get('seq', 0) for r in rows), default=0)
request = dict(session_id=saved['session_id'], workspace_id=EXPECTED_ID, stage=options.stage,
               before_seq=before, workspace_bound_before_call=True)
(ROOT / '.session-audit/native-main-contract-request.json').write_text(json.dumps(request, indent=2), encoding='utf-8')
scope_descriptions = {
    'syntax': '本步只做Python3.11语法静态检查，不导入业务、不访问Docker、不调用真实模型。',
    'baseline': '本步对冻结的原main执行离线契约反例，预期可能失败，保留原始失败，不改测试或源码。',
    'regression': '本步在只读1CPU/1GiB容器中执行当前候选的tests和evaluation，不调用真实模型。',
    'build': '本步仅在相同源码已通过回归后构建独立候选镜像并核对身份，不调用真实模型。',
    'acceptance': '本步先执行模拟网关故障检查，再对实际新镜像运行已授权的公开11题和独立D重复轮，使用现有magic真实接口；凭据仅由既有桥在内存读取，不打印、不供给镜像，只传临时本地桥令牌。',
    'archive': '本步仅在同一不可变镜像完成本地验收后导出tar、重新导入核对身份、新容器健康检查、保存源码及校验值，不调用模型，不上传赛事。'
}
message = (f"继续今天的验收。队友的新 main 已确认为64f5efd，Codex已在现有项目独立分支开始修复；历史v8与新main不能混用结果。"
           f"请仅在本对话的原生工具中执行一次 & 'C:/Users/lenovo/AppData/Local/Programs/Python/Python314/python.exe' "
           f"'C:/Users/lenovo/Desktop/Agent挑战赛/镜像测试/native_main_contract_run.py' --stage {options.stage}。"
           "工作目录C:/Users/lenovo/Desktop/Agent挑战赛。" + scope_descriptions[options.stage] +
           "只运行一次并等待完成；后台则监控同一任务。Docker若需审批，正常申请并等待用户，不绕过、不修改策略。"
           "不新建对话/工作区，不读取或展示凭据，不提交赛事。报告实际运行目录、用例数和失败原因。")
# Current screenshot verified the fixed main conversation and this composer/send control.
point(900, 1080, True)
chord(0x11, 0x41)
type_text(message)
point(1673, 1150, True)
acknowledged = False
for _ in range(50):
    rows, _ = native_rows(saved['session_id'])
    acknowledged = any(r.get('seq', 0) > before and r.get('type') == 'user/message'
                       and 'native_main_contract_run.py' in json.dumps(r, ensure_ascii=False)
                       and '--stage ' + options.stage in json.dumps(r, ensure_ascii=False) for r in rows)
    if acknowledged:
        break
    time.sleep(.2)
if not acknowledged:
    raise RuntimeError('No native acknowledgment; inspect UI before any retry')
print(json.dumps(dict(submitted=True, stage=options.stage, session_id=saved['session_id'], workspace_bound=True)))
