"""Offline source inspection only: no imports, data tests, Docker or model calls."""
import ast
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent.parent
repo = root / '协同开发/research-agent'
paths = [repo / 'agent.py']
paths += [path for name in ('src', 'tests', 'evaluation') for path in (repo / name).rglob('*.py')
          if '__pycache__' not in path.parts]
paths += [root / '镜像测试/native_main_contract_run.py', root / '镜像测试/main_contract_acceptance.py',
          root / '镜像测试/main_contract_paper_audit.py', root / '镜像测试/main_contract_faults.py',
          root / '镜像测试/main_contract_archive.py',
          root / '.session-audit/dispatch_main_contract_20261024.py']
errors = []
for path in paths:
    try:
        ast.parse(path.read_text(encoding='utf-8-sig'), filename=str(path), feature_version=(3, 11))
    except SyntaxError as exc:
        errors.append(dict(file=path.relative_to(root).as_posix(), line=exc.lineno, error=exc.msg))
record = dict(scope='OFFLINE_SOURCE_INSPECTION_ONLY', python_feature_version='3.11', files_parsed=len(paths),
              errors=errors, functional_tests_run=0, model_calls=0,
              source_sha256={p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})
(root / '.session-audit/source-static-check-047.json').write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(dict(files_parsed=len(paths), errors=errors, functional_tests_run=0, model_calls=0), ensure_ascii=True))
raise SystemExit(bool(errors))
