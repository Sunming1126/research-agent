"""Additional behavior regressions exposed by actual-paper appendix controls."""
from dataclasses import asdict
import hashlib
import json
from types import SimpleNamespace

import fitz
import pytest

from research_agent.core.config import Settings
from research_agent.core.utils import sha256_bytes
from research_agent.rag.materials import DocumentIndex
from research_agent.rag.retrieval import HybridRetriever,QueryPlan
from research_agent.workflows.tasks import TaskHandlers


def make_appendix_index(tmp_path,heading='A\nAppendix'):
    papers=tmp_path/'papers';papers.mkdir()
    with fitz.open() as document:
        for page in range(1,10):
            text='Neutral laboratory apparatus and operating conditions.'
            if page==4:text='References\n\n'+text
            if page==7:text=heading+'\n\nWe measure xenocalibration isotopeperturbation in our own appendix.'
            document.new_page().insert_text((40,80),text)
        document.save(papers/'scope.pdf')
    index=DocumentIndex(Settings(tmp_path,tmp_path/'out','fixture',material_roots=[papers]),tmp_path/'cache')
    index.parser.extract_tables=False
    index.build(['scope.pdf'],page_limit=4)
    return index


class AppendixReader:
    def json(self,stage,payload,**kwargs):
        assert stage=='retrieve'
        return {'papers':[{'filename':p['filename'],'decision':'include','relevant':True,
            'chunk_ids':[c['chunk_id'] for c in p['chunks'] if 'xenocalibration isotopeperturbation' in c['text']],
            'reason':'The literal original method evidence is supplied.'}
            for p in payload['candidates'] if any('xenocalibration isotopeperturbation' in c['text'] for c in p['chunks'])]}


@pytest.mark.parametrize('heading',['A\nAppendix','1\nAppendix'])
def test_full_document_expansion_preserves_numbered_appendix(tmp_path,heading):
    index=make_appendix_index(tmp_path,heading)
    handler=TaskHandlers(AppendixReader(),'fixture')
    handler.document_probe=lambda queries:index.probe_deep_pages(queries,4)
    handler.document_expander=index.expand_documents
    text='Find the own appendix method xenocalibration isotopeperturbation'
    case=SimpleNamespace(case_id='B-96',input=text,to_dict=lambda:{'input':text})
    result=handler.retrieval(case,HybridRetriever(index.chunks),QueryPlan(text))
    assert [p['filename'] for p in result['papers']]==['scope.pdf']
    assert any(c.page==7 for c in handler.selected_chunks)


def test_legacy_cache_with_old_appendix_classification_is_not_reused(tmp_path):
    index=make_appendix_index(tmp_path)
    material=index.materials[0]
    rows=[asdict(c) for c in index.chunker.chunk(material,index.parser.pages(material))]
    for row in rows:
        if row['page']>=7:row.update(kind='references',heading='References')
    legacy_identity=f'{material.filename}|{material.sha256}|{index.parser.VERSION}|850|110|{index.parser.ocr}|text-blocks-only'
    legacy=index.cache/(sha256_bytes(legacy_identity.encode())+'.json')
    legacy.write_text(json.dumps({'chunks':rows}),encoding='utf-8')
    before=hashlib.sha256(legacy.read_bytes()).hexdigest()
    rebuilt=index.build(['scope.pdf'])
    assert any(c.page==7 and c.kind!='references' and 'xenocalibration' in c.text for c in rebuilt)
    assert legacy.is_file() and hashlib.sha256(legacy.read_bytes()).hexdigest()==before


def test_larger_probe_cap_still_reserves_model_time_during_scan(tmp_path,monkeypatch):
    import research_agent.rag.deep_probe as module
    index=make_appendix_index(tmp_path)
    remaining=iter([110.,100.,94.])
    monkeypatch.setattr(module,'current_session',lambda:SimpleNamespace(remaining=lambda:next(remaining)))
    _,trace=index.probe_deep_pages(['xenocalibration'],4)
    assert trace['scanned_pages']==1 and trace['stop_reason']=='model_time_reserved'
    assert trace['coverage_limited']
