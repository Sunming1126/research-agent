"""Prepared scope counterexamples, not executed or accepted yet.

Synthetic PDF ground truth is defined here. The deterministic reader merely
checks delivered text; it does not estimate real model precision or recall.
"""
from types import SimpleNamespace

import fitz
import pytest

from research_agent.core.config import Settings
from research_agent.rag.materials import DocumentIndex
from research_agent.rag.retrieval import HybridRetriever,QueryPlan
from research_agent.workflows.tasks import TaskHandlers

NEEDLE='xenocalibration isotopeperturbation'


def material(path,*,reference_page=None,target_page=None,appendix_page=None):
    path.parent.mkdir(parents=True,exist_ok=True)
    with fitz.open() as document:
        for number in range(1,10):
            lines=[]
            if number==reference_page:lines.append('References')
            if number==appendix_page:lines.append('Appendix A')
            lines.append('Neutral laboratory apparatus and operating conditions.')
            if number==target_page:lines.append('We measure '+NEEDLE+' under controlled conditions.')
            document.new_page().insert_text((40,80),'\n\n'.join(lines))
        document.save(path)


class Reader:
    def json(self,stage,payload,**kwargs):
        assert stage=='retrieve'
        return {'papers':[{'filename':p['filename'],'decision':'include','relevant':True,
            'chunk_ids':[c['chunk_id'] for c in p['chunks'] if NEEDLE in c['text']],
            'reason':'The required literal method statement is present in supplied body evidence.'}
            for p in payload['candidates'] if any(NEEDLE in c['text'] for c in p['chunks'])]}


def retrieve(tmp_path,**pdf):
    papers=tmp_path/'papers';material(papers/'scope.pdf',**pdf)
    index=DocumentIndex(Settings(tmp_path,tmp_path/'out','fixture',material_roots=[papers]),tmp_path/'cache')
    index.parser.extract_tables=False
    prefix=index.build(['scope.pdf'],page_limit=4)
    handler=TaskHandlers(Reader(),'fixture')
    handler.document_probe=lambda queries:index.probe_deep_pages(queries,4)
    question='Find the paper with its own body method '+NEEDLE+'; bibliography mentions do not qualify.'
    case=SimpleNamespace(case_id='B-95',input=question,to_dict=lambda:{'input':question})
    answer=handler.retrieval(case,HybridRetriever(prefix),QueryPlan(NEEDLE))
    return answer,handler,index


def test_reference_title_in_prefix_does_not_authorize_continuation_as_body(tmp_path):
    answer,handler,index=retrieve(tmp_path,reference_page=4,target_page=5)
    assert any(c.kind=='references' and c.page==4 for c in index.chunks)
    assert answer['papers']==[]


def test_reference_title_on_prior_prefix_page_keeps_context_across_blankish_page(tmp_path):
    answer,_,_=retrieve(tmp_path,reference_page=3,target_page=5)
    assert answer['papers']==[]


def test_appendix_after_prefix_reference_restores_eligible_body(tmp_path):
    answer,handler,_=retrieve(tmp_path,reference_page=4,appendix_page=7,target_page=7)
    assert [p['filename'] for p in answer['papers']]==['scope.pdf']
    assert any(c.page==7 for c in handler.selected_chunks)


def test_reference_title_in_unread_range_still_excludes_same_page(tmp_path):
    answer,_,_=retrieve(tmp_path,reference_page=5,target_page=5)
    assert answer['papers']==[]


def test_plain_body_positive_is_preserved(tmp_path):
    answer,_,_=retrieve(tmp_path,target_page=7)
    assert [p['filename'] for p in answer['papers']]==['scope.pdf']


def test_missing_phrase_does_not_return_a_paper(tmp_path):
    answer,_,_=retrieve(tmp_path)
    assert answer['papers']==[]
