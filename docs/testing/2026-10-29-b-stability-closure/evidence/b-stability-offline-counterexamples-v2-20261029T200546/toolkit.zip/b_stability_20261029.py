"""Only runs from a fresh native tool call in the fixed Harness main session."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import zipfile

ROOT=Path(__file__).resolve().parent.parent
HERE=ROOT/'镜像测试'
DATA=HERE/'b-stability-20261029'
BASE=HERE/'审核/2026-10-29-quality-baseline-a329dd6/source'
SOURCE=HERE/'审核/2026-10-29-b-stability-current-43f8189/source'
PROTOTYPE=HERE/'审核/2026-10-29-b-stability-reference-prototype/source'
SID='session-9c903d0e-5884-44fe-bc7f-3719da00864b'
WID='c61ec5e8-9932-4ef5-9709-fed302ad7355'
PY312=HERE/'runtime/windows-python312/python.exe'


def save(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def proof(stage):
    from native_workspace_harness import workspace,native_rows,selection
    assert SID in workspace()['sessionIds'];selection()
    ticket=json.loads((ROOT/'.session-audit/b-stability-requests-20261029'/f'{stage}.json').read_text())
    assert ticket['stage']==stage and ticket['session_id']==SID and ticket['workspace_id']==WID
    deadline=time.monotonic()+30
    while time.monotonic()<deadline:
        rows,_=native_rows(SID)
        for row in rows:
            if row.get('seq',0)<=ticket['before_seq'] or row.get('type')!='assistant/message':continue
            for part in row.get('data',{}).get('message',{}).get('content',[]):
                text=json.dumps(part,ensure_ascii=False)
                if part.get('type')=='tool-call' and 'b_stability_20261029.py' in text and '--stage '+stage in text:
                    return {'session_id':SID,'workspace_id':WID,'native_tool_execution_verified':True,
                        'magic_selection_verified':True,'native_tool_sha256':hashlib.sha256(text.encode()).hexdigest()}
        time.sleep(.3)
    raise RuntimeError('No fresh native invocation verified; refuse to run tests')


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--stage',choices=['diagnostic','profile','counterexamples'],required=True)
    stage=parser.parse_args().stage
    native=proof(stage)
    expected=json.loads((DATA/'source-files.json').read_text())
    assert len(expected)==193 and all(hashlib.sha256((SOURCE/n).read_bytes()).hexdigest()==v for n,v in expected.items())
    for source,filename in [(BASE,'baseline-source-files.json'),(PROTOTYPE,'prototype-source-files.json')]:
        snapshot=json.loads((DATA/filename).read_text())
        assert all(hashlib.sha256((source/n).read_bytes()).hexdigest()==v for n,v in snapshot.items())
    out=HERE/'runs'/('b-stability-'+stage+'-'+time.strftime('%Y%m%dT%H%M%S'))
    out.mkdir(parents=True,exist_ok=False)
    save(out/'native-proof.json',native);save(out/'source-files.json',expected)
    save(ROOT/f'.session-audit/b-stability-{stage}-latest.json',{'run':str(out)})
    for variant,source in [('baseline',BASE),('comparison',SOURCE),('reference-context-prototype',PROTOTYPE)]:
        with zipfile.ZipFile(out/(variant+'-source.zip'),'x',compression=zipfile.ZIP_DEFLATED) as z:
            for p in sorted(source.rglob('*.py')):
                if '__pycache__' not in p.parts:z.writestr(p.relative_to(source).as_posix(),p.read_bytes())
    with zipfile.ZipFile(out/'toolkit.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(HERE.glob('b_stability*20261029.py')):z.writestr(p.name,p.read_bytes())
    (out/'manifest.json').write_bytes((DATA/'manifest.json').read_bytes())
    os.environ.update(ANIC_NATIVE_ORCHESTRATOR_SESSION_ID=SID,RESEARCH_RUNTIME='local',
        AGENTHACK_TELEMETRY_REQUIRED='false',PYTHONDONTWRITEBYTECODE='1')
    if stage=='counterexamples':
        from b_depth_20261029 import run_tests
        frozen=out/'frozen-tests/test_probe_reference_context.py';frozen.parent.mkdir()
        frozen.write_bytes((HERE/'b_stability_counterexamples_20261029.py').read_bytes())
        results={v:run_tests(s,out/v,[frozen]) for v,s in [('baseline',BASE),('comparison',SOURCE),('reference-context-prototype',PROTOTYPE)]}
        save(out/'summary.json',{'results':results,'test_sha256':hashlib.sha256(frozen.read_bytes()).hexdigest(),
            'target_model_calls':0,'new_strategy_adopted':False})
        print(json.dumps(results));return
    paths=[str(SOURCE),str(SOURCE/'src'),str(HERE/'runtime/py312-windows'),str(HERE)]
    worker=HERE/'b_stability_worker_20261029.py'
    boot='import sys,runpy;sys.path[:0]='+repr(paths)+';runpy.run_path('+repr(str(worker))+',run_name="__main__")'
    result=subprocess.run([str(PY312),'-X','utf8','-c',boot,'--directory',str(out),'--stage',stage],
        cwd=SOURCE,capture_output=True,timeout=1500)
    (out/'stdout.txt').write_bytes(result.stdout);(out/'stderr.txt').write_bytes(result.stderr)
    save(out/'execution.json',{'returncode':result.returncode})
    print(result.stdout.decode('utf-8',errors='replace')[-1600:])
    raise SystemExit(result.returncode)


if __name__=='__main__':main()
