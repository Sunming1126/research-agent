"""Explicitly authorized no-model follow-up: reference state x bounded time cap."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import zipfile

ROOT=Path(__file__).resolve().parent.parent
HERE=ROOT/'镜像测试';DATA=HERE/'b-stability-20261029'
PY312=HERE/'runtime/windows-python312/python.exe'
SOURCES={
    'baseline':(HERE/'审核/2026-10-29-quality-baseline-a329dd6/source','baseline-source-files.json'),
    'comparison':(HERE/'审核/2026-10-29-b-stability-current-43f8189/source','source-files.json'),
    'reference':(HERE/'审核/2026-10-29-b-stability-reference-prototype/source','prototype-source-files.json'),
    'budget':(HERE/'审核/2026-10-29-b-stability-budget-prototype/source','budget-source-files.json'),
    'combined':(HERE/'审核/2026-10-29-b-stability-combined-prototype/source','combined-source-files.json')}


def save(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def main():
    os.environ.pop('ANIC_NATIVE_ORCHESTRATOR_SESSION_ID',None)
    os.environ.update(ANIC_OFFLINE_TEST_AUTHORIZATION='20261029-b-stability-user-approved',RESEARCH_RUNTIME='local',
        AGENTHACK_TELEMETRY_REQUIRED='false',PYTHONDONTWRITEBYTECODE='1')
    plan=json.loads((DATA/'factorial-manifest.json').read_text(encoding='utf-8'))
    questions=json.loads((DATA/'manifest.json').read_text(encoding='utf-8'))
    out=HERE/'runs'/('b-stability-offline-factorial-'+time.strftime('%Y%m%dT%H%M%S'));out.mkdir(parents=True)
    save(out/'execution-mode.json',{'mode':'offline-authorized','native_harness_execution':False,'target_model_calls':0,
        'authorization':'Explicit user approval in this conversation; scoped to offline no-model tests'})
    save(ROOT/'.session-audit/b-stability-offline-factorial-latest.json',{'run':str(out)})
    save(out/'factorial-manifest.json',plan)
    for variant,(source,mapping) in SOURCES.items():
        expected=json.loads((DATA/mapping).read_text())
        assert all(hashlib.sha256((source/n).read_bytes()).hexdigest()==v for n,v in expected.items())
        save(out/(variant+'-source-files.json'),expected)
        with zipfile.ZipFile(out/(variant+'-source.zip'),'x',compression=zipfile.ZIP_DEFLATED) as z:
            for n in expected:z.writestr(n,(source/n).read_bytes())
    with zipfile.ZipFile(out/'toolkit.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(HERE.glob('b_stability*20261029.py')):z.writestr(p.name,p.read_bytes())
        z.writestr('offline_network_guard_20261029.py',(HERE/'offline_network_guard_20261029.py').read_bytes())
    schedule=[]
    variants=plan['variants']
    for repetition in range(plan['repetitions']):
        for number,key in enumerate(plan['case_keys']):
            offset=(repetition*len(plan['case_keys'])+number)%len(variants)
            order=variants[offset:]+variants[:offset]
            for variant in order:schedule.append((repetition,key,variant))
    save(out/'schedule.json',{'tasks':schedule,'order':'rotating start offset, not a fully randomized design'})
    results=[]
    for sequence,(repetition,key,variant) in enumerate(schedule):
        directory=out/f'{sequence:02d}-{key}-{variant}';directory.mkdir()
        source=SOURCES[variant][0]
        paths=[str(source),str(source/'src'),str(HERE/'runtime/py312-windows'),str(HERE)]
        worker=HERE/'b_stability_worker_20261029.py'
        boot='import sys;sys.path[:0]='+repr(paths)+';import offline_network_guard_20261029;import runpy;runpy.run_path('+repr(str(worker))+',run_name="__main__")'
        env=os.environ.copy();env['ANIC_OFFLINE_NETWORK_GUARD_LOG']=str(directory/'network-guard.json')
        command=[str(PY312),'-X','utf8','-c',boot,'--directory',str(directory),'--stage','diagnostic',
            '--worker','--variant',variant,'--item-key',key,'--execution-mode','offline-authorized']
        start=time.monotonic()
        try:
            done=subprocess.run(command,cwd=source,env=env,capture_output=True,timeout=180)
            (directory/'stdout.txt').write_bytes(done.stdout);(directory/'stderr.txt').write_bytes(done.stderr)
            row=json.loads((directory/'result.json').read_text(encoding='utf-8')) if done.returncode==0 else {'status':'worker_failed','returncode':done.returncode}
        except subprocess.TimeoutExpired as exc:
            (directory/'stdout.txt').write_bytes(exc.stdout or b'');(directory/'stderr.txt').write_bytes(exc.stderr or b'')
            row={'status':'worker_timeout'}
        expected=next(i['expected_filenames'] for i in questions['items'] if i['key']==key)
        row.update(variant=variant,item_key=key,repetition=repetition,worker_wall_seconds=time.monotonic()-start,expected=expected)
        actual=set(row.get('actual',[]))
        row.update(exact='actual' in row and actual==set(expected),false_positives=sorted(actual-set(expected)),missed=sorted(set(expected)-actual))
        results.append(row)
        save(out/'summary.json',{'results':results,'complete':False,'target_model_calls':0,'new_strategy_adopted':False})
        print(json.dumps({k:row.get(k) for k in ['variant','item_key','repetition','exact','seconds','status']},ensure_ascii=False),flush=True)
    save(out/'summary.json',{'results':results,'complete':True,'target_model_calls':0,'new_strategy_adopted':False,
        'limits':'Existing literal diagnostics; exploratory after first comparison; not statistical significance, real-model quality, or Linux acceptance'})


if __name__=='__main__':main()
