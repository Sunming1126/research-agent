"""Explicitly user-authorized offline entry. Never claims native Harness execution."""
import argparse
from datetime import datetime,timezone,timedelta
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
import zipfile

ROOT=Path(__file__).resolve().parent.parent
HERE=ROOT/'镜像测试';DATA=HERE/'b-stability-20261029'
BASE=HERE/'审核/2026-10-29-quality-baseline-a329dd6/source'
SOURCE=HERE/'审核/2026-10-29-b-stability-current-43f8189/source'
PROTO=HERE/'审核/2026-10-29-b-stability-reference-prototype/source'
ACTIVE=ROOT/'协同开发/research-agent-stability-20261027'
PY312=HERE/'runtime/windows-python312/python.exe'


def save(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def pytest_run(source,out,test):
    out.mkdir()
    paths=[str(source),str(source/'src'),str(ACTIVE/'tests'),str(HERE/'runtime/py312-windows'),str(HERE)]
    boot='import sys;sys.path[:0]='+repr(paths)+';import offline_network_guard_20261029;import pytest;raise SystemExit(pytest.main(sys.argv[1:]))'
    env=os.environ.copy()
    env.update(ANIC_OFFLINE_NETWORK_GUARD_LOG=str(out/'network-guard.json'),PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',
        RESEARCH_TEST_PAPERS=str(ROOT/'测试输入/交付镜像/team_share/papers'),
        PUBLIC_EXPERIMENT_ROOT=str(ROOT/'测试输入/交付镜像/team_share/experiments/research-experiments'),
        TEMP=str(out),TMP=str(out),TMPDIR=str(out))
    cmd=[str(PY312),'-X','utf8','-c',boot,'-q','-p','no:cacheprovider','--basetemp='+str(out/'temp'),
         '--junitxml='+str(out/'pytest.xml'),*map(str,test)]
    start=time.monotonic();done=subprocess.run(cmd,cwd=source,env=env,capture_output=True,timeout=600)
    (out/'stdout.txt').write_bytes(done.stdout);(out/'stderr.txt').write_bytes(done.stderr)
    cases=ET.parse(out/'pytest.xml').getroot().findall('.//testcase') if (out/'pytest.xml').exists() else []
    result={'returncode':done.returncode,'collected':len(cases),'failures':sum(c.find('failure') is not None for c in cases),
        'errors':sum(c.find('error') is not None for c in cases),'skipped':sum(c.find('skipped') is not None for c in cases),
        'seconds':round(time.monotonic()-start,3),'mode':'offline-authorized','native_harness_execution':False,'target_model_calls':0}
    result['passed']=len(cases)-result['failures']-result['errors']-result['skipped']
    save(out/'summary.json',result);save(out/'command.json',cmd)
    print(json.dumps({'source':source.parent.name,**result},ensure_ascii=False),flush=True)
    return result


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--stage',choices=['counterexamples','diagnostic','profile','regression-prototype'],required=True)
    stage=parser.parse_args().stage
    assert ROOT==Path('C:/Users/lenovo/Desktop/Agent挑战赛')
    os.environ.pop('ANIC_NATIVE_ORCHESTRATOR_SESSION_ID',None)
    os.environ.update(ANIC_OFFLINE_TEST_AUTHORIZATION='20261029-b-stability-user-approved',RESEARCH_RUNTIME='local',
        AGENTHACK_TELEMETRY_REQUIRED='false',PYTHONDONTWRITEBYTECODE='1')
    out=HERE/'runs'/('b-stability-offline-'+stage+'-'+time.strftime('%Y%m%dT%H%M%S'))
    out.mkdir(parents=True,exist_ok=False)
    save(out/'execution-mode.json',{'mode':'offline-authorized','native_harness_execution':False,
        'authorization':'User explicitly answered 允许本轮离线无模型测试 in this conversation on 2026-10-29',
        'target_model_calls':0,'real_model_testing_still_requires_original_harness':True,
        'date':datetime.now(timezone.utc).astimezone(timezone(timedelta(hours=8))).isoformat()})
    save(ROOT/f'.session-audit/b-stability-offline-{stage}-latest.json',{'run':str(out)})
    for v,source,manifest in [('baseline',BASE,'baseline-source-files.json'),('comparison',SOURCE,'source-files.json'),('prototype',PROTO,'prototype-source-files.json')]:
        expected=json.loads((DATA/manifest).read_text())
        assert all(hashlib.sha256((source/n).read_bytes()).hexdigest()==d for n,d in expected.items())
        save(out/(v+'-source-files.json'),expected)
        with zipfile.ZipFile(out/(v+'-source.zip'),'x',compression=zipfile.ZIP_DEFLATED) as z:
            for n in expected:z.writestr(n,(source/n).read_bytes())
    with zipfile.ZipFile(out/'toolkit.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(HERE.glob('b_stability*20261029.py')):z.writestr(p.name,p.read_bytes())
        z.writestr('offline_network_guard_20261029.py',(HERE/'offline_network_guard_20261029.py').read_bytes())
    (out/'manifest.json').write_bytes((DATA/'manifest.json').read_bytes())
    if stage=='counterexamples':
        test=out/'frozen-tests/test_probe_reference_context.py';test.parent.mkdir()
        test.write_bytes((HERE/'b_stability_counterexamples_20261029.py').read_bytes())
        results={v:pytest_run(s,out/v,[test]) for v,s in [('baseline',BASE),('comparison',SOURCE),('prototype',PROTO)]}
        save(out/'summary.json',{'results':results,'test_sha256':hashlib.sha256(test.read_bytes()).hexdigest(),
            'mode':'offline-authorized','target_model_calls':0,'new_strategy_adopted':False});return
    if stage=='regression-prototype':
        result=pytest_run(PROTO,out/'prototype',[PROTO/'tests'])
        save(out/'summary.json',result);raise SystemExit(result['returncode'])
    paths=[str(SOURCE),str(SOURCE/'src'),str(HERE/'runtime/py312-windows'),str(HERE)]
    worker=HERE/'b_stability_worker_20261029.py'
    boot='import sys,runpy;sys.path[:0]='+repr(paths)+';runpy.run_path('+repr(str(worker))+',run_name="__main__")'
    done=subprocess.run([str(PY312),'-X','utf8','-c',boot,'--directory',str(out),'--stage',stage,
        '--execution-mode','offline-authorized'],cwd=SOURCE,capture_output=True,timeout=1500)
    (out/'stdout.txt').write_bytes(done.stdout);(out/'stderr.txt').write_bytes(done.stderr)
    save(out/'execution.json',{'returncode':done.returncode})
    print(done.stdout.decode('utf-8',errors='replace')[-1800:]);raise SystemExit(done.returncode)


if __name__=='__main__':main()
