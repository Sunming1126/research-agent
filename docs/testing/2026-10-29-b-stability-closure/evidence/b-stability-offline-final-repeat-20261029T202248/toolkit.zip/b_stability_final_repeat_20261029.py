"""Offline original-material boundary controls or broader literal regression."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import zipfile

from b_stability_offline_20261029 import ROOT,HERE,DATA,PY312,save


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--suite',choices=['final-repeat'],required=True)
    parser.add_argument('--sources',type=Path,required=True)
    args=parser.parse_args()
    os.environ.pop('ANIC_NATIVE_ORCHESTRATOR_SESSION_ID',None)
    os.environ.update(ANIC_OFFLINE_TEST_AUTHORIZATION='20261029-b-stability-user-approved',RESEARCH_RUNTIME='local',
        AGENTHACK_TELEMETRY_REQUIRED='false',PYTHONDONTWRITEBYTECODE='1')
    definitions=json.loads(args.sources.read_text(encoding='utf-8'))
    manifest_path=DATA/'final-repeat-manifest.json'
    manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
    out=HERE/'runs'/('b-stability-offline-'+args.suite+'-'+time.strftime('%Y%m%dT%H%M%S'));out.mkdir()
    save(ROOT/f'.session-audit/b-stability-offline-{args.suite}-latest.json',{'run':str(out)})
    save(out/'execution-mode.json',{'mode':'offline-authorized','native_harness_execution':False,'target_model_calls':0})
    save(out/'manifest.json',manifest);save(out/'sources.json',definitions)
    for variant,spec in definitions.items():
        source=(ROOT/spec['source']).resolve();assert source.is_relative_to(HERE/'审核') or source.is_relative_to(ROOT/'协同开发')
        proof=json.loads((ROOT/spec['files_manifest']).read_text())
        assert all(hashlib.sha256((source/n).read_bytes()).hexdigest()==v for n,v in proof.items())
        save(out/(variant+'-source-files.json'),proof)
        with zipfile.ZipFile(out/(variant+'-source.zip'),'x',compression=zipfile.ZIP_DEFLATED) as z:
            for n in proof:z.writestr(n,(source/n).read_bytes())
    with zipfile.ZipFile(out/'toolkit.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
        for p in [Path(__file__),HERE/'b_stability_extended_worker_20261029.py',HERE/'offline_network_guard_20261029.py']:
            z.writestr(p.name,p.read_bytes())
    results=[];variants=list(definitions)
    for number,item in enumerate(manifest['items']):
        offset=number%len(variants);order=variants[offset:]+variants[:offset]
        for variant in order:
            directory=out/(item['key']+'-'+variant);directory.mkdir()
            source=ROOT/definitions[variant]['source']
            paths=[str(source),str(source/'src'),str(HERE/'runtime/py312-windows'),str(HERE)]
            worker=HERE/'b_stability_extended_worker_20261029.py'
            boot='import sys;sys.path[:0]='+repr(paths)+';import offline_network_guard_20261029;import runpy;runpy.run_path('+repr(str(worker))+',run_name="__main__")'
            env=os.environ.copy();env['ANIC_OFFLINE_NETWORK_GUARD_LOG']=str(directory/'network-guard.json')
            start=time.monotonic()
            try:
                done=subprocess.run([str(PY312),'-X','utf8','-c',boot,'--directory',str(directory),'--stage','diagnostic',
                    '--worker','--variant',variant,'--item-key',item['key'],'--manifest',str(manifest_path),
                    '--execution-mode','offline-authorized'],cwd=source,env=env,capture_output=True,timeout=180)
                (directory/'stdout.txt').write_bytes(done.stdout);(directory/'stderr.txt').write_bytes(done.stderr)
                row=json.loads((directory/'result.json').read_text(encoding='utf-8')) if done.returncode==0 else {'status':'worker_failed','returncode':done.returncode}
            except subprocess.TimeoutExpired as exc:
                (directory/'stdout.txt').write_bytes(exc.stdout or b'');(directory/'stderr.txt').write_bytes(exc.stderr or b'')
                row={'status':'worker_timeout'}
            expected=set(item['expected_filenames']);actual=set(row.get('actual',[]))
            row.update(variant=variant,item_key=item['key'],expected=sorted(expected),exact='actual' in row and actual==expected,
                false_positives=sorted(actual-expected),missed=sorted(expected-actual),worker_wall_seconds=time.monotonic()-start)
            results.append(row)
            save(out/'summary.json',{'results':results,'complete':False,'mode':'offline-authorized','target_model_calls':0})
            print(json.dumps({k:row.get(k) for k in ['item_key','variant','exact','seconds','status']},ensure_ascii=False),flush=True)
    save(out/'summary.json',{'results':results,'complete':True,'mode':'offline-authorized','target_model_calls':0,
        'limits':manifest.get('scope','Existing disclosed literal regression, not broad semantic relevance or real-model scores')})


if __name__=='__main__':main()
