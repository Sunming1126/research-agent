"""Deny outbound network in the explicitly authorized no-model test processes."""
import ipaddress
import json
import os
from pathlib import Path
import socket

assert os.environ.get('ANIC_OFFLINE_TEST_AUTHORIZATION')=='20261029-b-stability-user-approved'
_path=Path(os.environ['ANIC_OFFLINE_NETWORK_GUARD_LOG'])
_state={'mode':'offline-authorized','external_network_allowed':False,'external_attempts_blocked':0,'credentials_logged':False}


def _write():
    _path.parent.mkdir(parents=True,exist_ok=True)
    _path.write_text(json.dumps(_state),encoding='utf-8')


def _check(address):
    if not isinstance(address,tuple):return
    host=address[0]
    if isinstance(host,bytes):host=host.decode('ascii',errors='replace')
    if host=='localhost':return
    try:
        if ipaddress.ip_address(host).is_loopback:return
    except ValueError:pass
    _state['external_attempts_blocked']+=1;_write()
    raise OSError('External network disabled for this authorized offline no-model test; destination withheld')


_connect=socket.socket.connect
_connect_ex=socket.socket.connect_ex


def _guard_connect(self,address):
    _check(address);return _connect(self,address)


def _guard_connect_ex(self,address):
    _check(address);return _connect_ex(self,address)


socket.socket.connect=_guard_connect
socket.socket.connect_ex=_guard_connect_ex
_write()
