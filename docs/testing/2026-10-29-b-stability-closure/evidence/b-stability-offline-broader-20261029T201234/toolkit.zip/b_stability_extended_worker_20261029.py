"""Prepared fixed-query comparisons and profiling; native coordinator required."""
import argparse
import cProfile
import ctypes
import hashlib
import json
import os
from pathlib import Path
import pstats
import subprocess
import sys
import time
import unicodedata
import re
from types import SimpleNamespace

ROOT=Path(__file__).resolve().parent.parent
HERE=ROOT/'镜像测试'
DATA=HERE/'b-stability-20261029'
LIB=ROOT/'科研资料/2026-10-29-扩充论文库/pdfs'
BASE=HERE/'审核/2026-10-29-quality-baseline-a329dd6/source'
SOURCE=HERE/'审核/2026-10-29-b-stability-current-43f8189/source'
SID='session-9c903d0e-5884-44fe-bc7f-3719da00864b'


def save(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def normalized(text):
    text=unicodedata.normalize('NFKC',text).lower()
    return re.sub(r'\s+',' ',re.sub(r'(?<=[a-z])-\s*\n\s*(?=[a-z])','',text))


def worker(out,variant,item_key,stage,manifest_path):
    from research_agent.core.config import Settings
    from research_agent.core.session import CaseSession
    from research_agent.rag.materials import DocumentIndex
    from research_agent.rag.retrieval import HybridRetriever,QueryPlan
    from research_agent.workflows.tasks import TaskHandlers
    manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
    item=next(i for i in manifest['items'] if i['key']==item_key)
    corpus=json.loads((DATA/'corpus.json').read_text(encoding='utf-8'))
    requested=set(item.get('scope_filenames') or [r['filename'] for r in corpus['papers']])
    assert requested <= {r['filename'] for r in corpus['papers']}
    files=[]
    for row in [r for r in corpus['papers'] if r['filename'] in requested]:
        assert hashlib.sha256((LIB/row['filename']).read_bytes()).hexdigest()==row['sha256']
        files.append(row['filename'])
    cache=out.parent/'shared-prefix-cache'/variant
    cache_files_before=len(list(cache.glob('*.json'))) if cache.exists() else 0
    index=DocumentIndex(Settings(ROOT,out/'output','fixed_query',material_roots=[LIB]),cache)
    index.parser.extract_tables=False
    start=time.monotonic();cpu=time.process_time()
    initial_pages=2 if len(files)>=250 else 4 if len(files)>=50 else 8
    chunks=index.build(files,page_limit=initial_pages,tolerate_pdf_errors=True)
    index_wall=time.monotonic()-start;index_cpu=time.process_time()-cpu
    plan=QueryPlan(**item['plan']);case=SimpleNamespace(**item['task'])
    case.to_dict=lambda:dict(item['task'])
    if stage=='profile':
        queries=[TaskHandlers._question_text(case),plan.topic,plan.methods,plan.focus,*plan.variants,*plan.subqueries]
        profiler=cProfile.Profile()
        start=time.monotonic();cpu=time.process_time()
        with CaseSession(item['case_id'],170).activate():
            deeper,trace=profiler.runcall(index.probe_deep_pages,queries,initial_pages,max_seconds=30)
        elapsed=time.monotonic()-start;cpu_elapsed=time.process_time()-cpu
        profiler.dump_stats(str(out/'probe.prof'))
        stats=pstats.Stats(profiler)
        top=[]
        for (filename,line,function),(primitive,total,own,cumulative,callers) in sorted(stats.stats.items(),key=lambda x:x[1][3],reverse=True)[:30]:
            top.append({'file':filename,'line':line,'function':function,'primitive_calls':primitive,'calls':total,
                'own_seconds':round(own,6),'cumulative_seconds':round(cumulative,6)})
        result={'stage':'profile','variant':variant,'case_id':item['case_id'],'probe':trace,
            'seconds':elapsed,'cpu_seconds':cpu_elapsed,'top':top,'deep_chunks':len(deeper),
            'limits':'cProfile overhead and 30-second profiling budget; not comparable to normal 12-second latency'}
    else:
        phrase=item['phrase']
        class Reader:
            def json(self,stage,payload,**kwargs):
                assert stage=='retrieve'
                return {'papers':[{'filename':p['filename'],'decision':'include','relevant':True,
                    'chunk_ids':[c['chunk_id'] for c in p['chunks'] if phrase in normalized(c['text'])],
                    'reason':'The supplied original text contains the requested continuous literal phrase.'}
                    for p in payload['candidates'] if any(phrase in normalized(c['text']) for c in p['chunks'])]}
        handler=TaskHandlers(Reader(),'fixed_query')
        handler.document_expander=index.expand_documents
        handler.document_probe=lambda queries:index.probe_deep_pages(queries,initial_pages)
        start=time.monotonic();cpu=time.process_time()
        with CaseSession(item['case_id'],170).activate():
            answer=handler.retrieval(case,HybridRetriever(chunks),plan)
        result={'stage':'diagnostic','variant':variant,'case_id':item['case_id'],'item_key':item_key,
            'actual':sorted(p['filename'] for p in answer['papers']),'seconds':time.monotonic()-start,
            'cpu_seconds':time.process_time()-cpu,'trace':handler.retrieval_trace}
    result.update(index_wall_seconds=index_wall,index_cpu_seconds=index_cpu,prefix_cache_files_before=cache_files_before,
        target_model_calls=0,model_tokens=0,material_errors=index.errors,authorized_documents=len(files),initial_page_limit=initial_pages,
        cache_control='JSON prefix cache shared per variant; fresh Python process per task; OS caches not controlled',
        environment='Windows source, no CPU/memory hard limits or Linux acceptance')
    save(out/'result.json',result)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--directory',type=Path,required=True)
    parser.add_argument('--stage',choices=['diagnostic','profile'],required=True)
    parser.add_argument('--worker',action='store_true')
    parser.add_argument('--variant',choices=['baseline','comparison','reference','budget','combined'])
    parser.add_argument('--item-key')
    parser.add_argument('--manifest',type=Path,required=True)
    parser.add_argument('--execution-mode',choices=['native','offline-authorized'],default='native')
    args=parser.parse_args()
    if args.execution_mode=='native':
        assert os.environ.get('ANIC_NATIVE_ORCHESTRATOR_SESSION_ID')==SID
    else:
        assert os.environ.get('ANIC_OFFLINE_TEST_AUTHORIZATION')=='20261029-b-stability-user-approved'
        assert not os.environ.get('ANIC_NATIVE_ORCHESTRATOR_SESSION_ID')
    out=args.directory.resolve();assert out.is_relative_to(HERE/'runs')
    if args.worker:return worker(out,args.variant,args.item_key,args.stage,args.manifest)
    manifest=json.loads((DATA/'manifest.json').read_text(encoding='utf-8'));schedule=[]
    if args.stage=='profile':schedule=[('baseline','B-50-fixed',0)]
    else:
        fixed=[i for i in manifest['items'] if i['factor']=='same_literal_query']
        for repetition in range(manifest['repetitions']):
            for number,item in enumerate(fixed):
                order=['baseline','comparison'] if (number+repetition)%2==0 else ['comparison','baseline']
                schedule.extend((v,item['key'],repetition) for v in order)
        replays=[i for i in manifest['items'] if i['factor']=='replay_frozen_query_on_same_baseline']
        for repetition in range(manifest['repetitions']):
            order=replays if repetition%2==0 else list(reversed(replays))
            schedule.extend(('baseline',i['key'],repetition) for i in order)
    save(out/'schedule.json',{'tasks':schedule,'target_model_calls_planned':0})
    results=[]
    for sequence,(variant,key,repetition) in enumerate(schedule):
        directory=out/f'{sequence:02d}-{key}-{variant}'
        directory.mkdir();source=BASE if variant=='baseline' else SOURCE
        paths=[str(source),str(source/'src'),str(HERE/'runtime/py312-windows'),str(HERE)]
        boot='import sys,runpy;sys.path[:0]='+repr(paths)+';runpy.run_path('+repr(str(Path(__file__)))+',run_name="__main__")'
        command=[sys.executable,'-X','utf8','-c',boot,'--directory',str(directory),'--stage',args.stage,
                 '--worker','--variant',variant,'--item-key',key,'--execution-mode',args.execution_mode]
        start=time.monotonic()
        try:
            child_env=os.environ.copy()
            child_env['ANIC_OFFLINE_NETWORK_GUARD_LOG']=str(directory/'network-guard.json')
            if args.execution_mode=='offline-authorized':
                boot='import sys;sys.path[:0]='+repr(paths)+';import offline_network_guard_20261029;import runpy;runpy.run_path('+repr(str(Path(__file__)))+',run_name="__main__")'
                command[4]=boot
            done=subprocess.run(command,cwd=source,env=child_env,capture_output=True,timeout=180)
            (directory/'stdout.txt').write_bytes(done.stdout);(directory/'stderr.txt').write_bytes(done.stderr)
            result=json.loads((directory/'result.json').read_text(encoding='utf-8')) if done.returncode==0 else {'status':'worker_failed','returncode':done.returncode}
        except subprocess.TimeoutExpired as exc:
            (directory/'stdout.txt').write_bytes(exc.stdout or b'');(directory/'stderr.txt').write_bytes(exc.stderr or b'')
            result={'status':'worker_timeout'}
        result.update(variant=variant,item_key=key,repetition=repetition,worker_wall_seconds=time.monotonic()-start)
        if 'actual' in result:
            expected=next(i['expected_filenames'] for i in manifest['items'] if i['key']==key)
            result.update(expected=expected,exact=result['actual']==sorted(expected),
                false_positives=sorted(set(result['actual'])-set(expected)),missed=sorted(set(expected)-set(result['actual'])))
        results.append(result)
        save(out/'summary.json',{'results':results,'complete':False,'target_model_calls':0,'new_strategy_adopted':False})
        print(json.dumps({'task':key,'variant':variant,'repeat':repetition,'status':result.get('status','completed'),
                          'exact':result.get('exact')},ensure_ascii=False),flush=True)
    save(out/'summary.json',{'results':results,'complete':True,'target_model_calls':0,'new_strategy_adopted':False,
        'limits':'Three repeats of existing disclosed literal diagnostics, not held-out model quality or statistical significance'})


if __name__=='__main__':main()
