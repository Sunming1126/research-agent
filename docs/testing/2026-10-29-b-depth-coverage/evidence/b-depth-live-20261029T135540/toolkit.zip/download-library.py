"""Build an append-only corpus of unique original public PDFs, from native Harness only."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import ssl
import time
import urllib.request

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / '科研资料/2026-10-29-扩充论文库'
PDFS = OUT / 'pdfs'
SID = 'session-9c903d0e-5884-44fe-bc7f-3719da00864b'


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert os.environ.get('ANIC_NATIVE_ORCHESTRATOR_SESSION_ID') == SID
    PDFS.mkdir(parents=True, exist_ok=True)
    old = json.loads((ROOT / '协同开发/research-agent-stability-20261027/paper_library/manifest-300.json').read_text(encoding='utf-8'))['papers']
    rows = []
    seed_dir = ROOT / '测试输入/交付镜像/team_share/papers'
    for path in sorted(seed_dir.glob('*.pdf')):
        identifier = re.match(r'\d{4}\.\d{4,5}', path.name).group()
        meta = next(p for p in old if p['arxiv_id'] == identifier)
        rows.append(dict(meta, source_local=str(path), filename=path.name))
    rows += [dict(arxiv_id=i, title=t, pdf_url='https://arxiv.org/pdf/'+i, abstract_url='https://arxiv.org/abs/'+i,
                  selected_category='cs.CL', filename=i+'.pdf', metadata_origin='official paper page checked 2026-10-29')
             for i,t in [('2401.15884','Corrective Retrieval Augmented Generation'),
                         ('2305.06983','Active Retrieval Augmented Generation'),
                         ('2212.10496','Precise Zero-Shot Dense Retrieval without Relevance Labels'),
                         ('2312.10997','Retrieval-Augmented Generation for Large Language Models: A Survey')]]
    categories = ['cs.CV','stat.ML','math.OC','q-bio.MN','astro-ph.GA','cond-mat.mtrl-sci','econ.GN','physics.optics']
    for category in categories:
        # Prefer smaller authentic public PDFs within each field when filling
        # missing material over the slow link. This is a diagnostic corpus,
        # not a sample representative of the natural paper-size distribution.
        available = sorted((p for p in old if p.get('selected_category') == category),
                           key=lambda p: (p.get('bytes', 25_000_000), p['arxiv_id']))
        for meta in available[:6]:
            rows.append(dict(meta, filename=meta['arxiv_id']+'.pdf'))
    chinese = ROOT / '科研资料/2026-10-29-B检索继续优化/搜索结果多样化研究综述-作者公开版.pdf'
    rows.append(dict(arxiv_id='ruc-diversification-2019', title='搜索结果多样化研究综述', selected_category='Chinese-IR',
                     pdf_url='https://playbigdata.ruc.edu.cn/dou/publication/2019_JC_Survey.pdf', source_local=str(chinese),
                     filename='ruc-diversification-2019.pdf', metadata_origin='author university public PDF'))
    selected = {p['arxiv_id'] for p in rows}
    rows += [dict(p, filename=p['arxiv_id']+'.pdf') for p in sorted(old, key=lambda p: p.get('bytes', 25_000_000))
             if p['arxiv_id'] not in selected][:50]
    prior = json.loads((OUT / 'downloads.json').read_text(encoding='utf-8')) if (OUT / 'downloads.json').exists() else {'papers': [], 'failures': []}
    papers = {p['id']: p for p in prior['papers']}
    failures = prior['failures']
    # CPython's Windows store here misses public issuer roots. Supplement it
    # with the existing isolated runtime's Mozilla CA bundle; verification and
    # hostname checks remain mandatory. Do not alter the system trust store.
    ca_bundle = ROOT / '镜像测试/runtime/py312-windows/certifi/cacert.pem'
    context = ssl.create_default_context()
    context.load_verify_locations(cafile=str(ca_bundle))
    assert context.verify_mode == ssl.CERT_REQUIRED and context.check_hostname
    save(OUT / 'download-transport.json', {'tls_verification': True, 'hostname_verification': True,
         'additional_ca_source': 'existing isolated certifi Mozilla public root bundle', 'ca_sha256': sha(ca_bundle)})
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), urllib.request.HTTPSHandler(context=context))
    started, last_request = time.monotonic(), 0.
    for meta in rows:
        if len(papers) >= 60 or time.monotonic()-started > 1100:
            break
        identifier = meta['arxiv_id']
        path = PDFS / meta['filename']
        assert path.resolve().is_relative_to(PDFS.resolve())
        if identifier in papers:
            assert path.is_file() and sha(path) == papers[identifier]['sha256']
            continue
        try:
            if meta.get('source_local'):
                data = Path(meta['source_local']).read_bytes()
            else:
                assert re.fullmatch(r'\d{4}\.\d{4,5}', identifier)
                if time.monotonic()-last_request < 3.2:
                    time.sleep(3.2-(time.monotonic()-last_request))
                last_request = time.monotonic()
                req = urllib.request.Request('https://arxiv.org/pdf/'+identifier,
                    headers={'User-Agent':'research-agent-public-corpus-research/1.0'})
                with opener.open(req, timeout=25) as response:
                    data = response.read(25_000_001)
            if not data.startswith(b'%PDF-') or len(data) > 25_000_000:
                raise ValueError('Invalid PDF signature or size')
            if path.exists():
                assert hashlib.sha256(data).hexdigest() == sha(path), 'Preserve different existing material'
            else:
                path.write_bytes(data)
            papers[identifier] = {'id': identifier, 'title': meta['title'], 'category': meta.get('selected_category'),
                'filename': path.name, 'source_url': meta.get('pdf_url'), 'abstract_url': meta.get('abstract_url'),
                'sha256': sha(path), 'bytes': len(data), 'downloaded_at': datetime.now(timezone.utc).isoformat(),
                'metadata_origin': meta.get('metadata_origin','historical official arXiv manifest; identity pending PDF validation'),
                'pdf_text_validation': 'pending native preflight'}
            print(json.dumps({'saved': len(papers), 'id': identifier, 'bytes': len(data)}, ensure_ascii=False), flush=True)
        except Exception as exc:
            failures.append({'id': identifier, 'error_type': type(exc).__name__, 'detail': str(exc)[:240],
                             'time': datetime.now(timezone.utc).isoformat()})
            print(json.dumps({'download_failed': identifier, 'error_type': type(exc).__name__}), flush=True)
        save(OUT / 'downloads.json', {'target': 60, 'count': len(papers), 'papers': list(papers.values()), 'failures': failures})
    print(json.dumps({'actual_downloads': len(papers), 'failures': len(failures), 'full_text_qualification': 'pending'}, ensure_ascii=False))


if __name__ == '__main__':
    main()
