"""Native-only PDF qualification and frozen late-page diagnostic construction."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import time
import unicodedata

ROOT = Path(__file__).resolve().parent.parent
LIB = ROOT / '科研资料/2026-10-29-扩充论文库'
OUT = ROOT / '镜像测试/depth-optimization-20261029'
SID = 'session-9c903d0e-5884-44fe-bc7f-3719da00864b'


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    assert not path.exists(), 'Frozen data already exists; inspect instead of overwriting'
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def norm(text):
    return ''.join(c for c in unicodedata.normalize('NFKC', text).casefold() if c.isalnum())


def main():
    assert os.environ.get('ANIC_NATIVE_ORCHESTRATOR_SESSION_ID') == SID
    from research_agent.rag.materials import DocumentParser, Chunker
    from research_agent.core.models import MaterialRef
    import fitz
    rows = json.loads((LIB / 'downloads.json').read_text(encoding='utf-8'))['papers']
    corpus, excluded, contents = [], [], {}
    parser = DocumentParser()
    parser.extract_tables = False
    started = time.monotonic()
    for row in rows:
        path = LIB / 'pdfs' / row['filename']
        try:
            assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
            with fitz.open(path) as doc:
                assert not doc.is_encrypted
                first = '\n'.join(doc[i].get_text() for i in range(min(2, len(doc))))
                pages_count = len(doc)
            expected = norm(row['title'])
            actual = norm(first)
            if expected not in actual:
                # Metadata spelling (e.g. hyphenation) may differ; require a
                # substantial multiword title match, never infer from filename.
                words = [w for w in re.findall(r'[a-z]{3,}', row['title'].lower())]
                assert len(words) >= 5 and sum(w in actual for w in words) / len(words) >= .85, 'title not validated'
            material = MaterialRef(path, path.name, 'pdf', row['sha256'])
            pages = parser.pages(material)
            chunks = Chunker().chunk(material, pages)
            assert sum(len(c.text) for c in chunks) >= 500
            contents[row['filename']] = {'pages': pages, 'chunks': chunks}
            corpus.append(dict(row, actual_pages=pages_count, text_characters=sum(len(p[1]) for p in pages),
                               pdf_text_validation='hash, unencrypted, title, extractable full text verified'))
        except Exception as exc:
            excluded.append({'filename': row['filename'], 'error_type': type(exc).__name__, 'reason': str(exc)[:160]})
    save(OUT / ('qualification-attempt-' + time.strftime('%Y%m%dT%H%M%S') + '.json'),
         {'qualified': len(corpus), 'excluded': excluded, 'downloaded': len(rows)})
    assert len(corpus) >= 7, 'Too few qualified documents for a meaningful diagnostic'
    save(OUT / 'corpus.json', {'created_at': datetime.now(timezone.utc).isoformat(), 'papers': corpus,
         'excluded': excluded, 'downloaded_count': len(rows), 'qualified_count': len(corpus),
         'model_calls': 0, 'seconds': round(time.monotonic() - started, 3)})
    # Labels are constructed from real text before either retrieval variant is
    # run. Exact phrases deliberately test late-page coverage, not broad
    # semantic relevance. No label is passed to the production engine.
    whole = {name: ' '.join(re.findall(r'[a-z]+', ' '.join(p[1] for p in item['pages']).lower()))
             for name, item in contents.items()}
    initial_limit = 2 if len(corpus) >= 250 else 4 if len(corpus) >= 50 else 8
    early_terms = set(re.findall(r'[a-z]{4,}', '\n'.join(p[1] for v in contents.values() for p in v['pages'] if p[0] <= initial_limit).lower()))
    examples = []
    for paper in sorted(corpus, key=lambda p: hashlib.sha256(p['sha256'].encode()).hexdigest()):
        item = contents[paper['filename']]
        choice = None
        for chunk in item['chunks']:
            if not chunk.page or chunk.page < max(8, initial_limit + 3) or chunk.kind != 'text':
                continue
            # Seven contiguous words in actual source, with at least two
            # distinctive words not visible in any four-page initial prefix.
            words = re.findall(r'[a-z]+', chunk.text.lower())
            for i in range(0, len(words) - 7):
                sample = words[i:i+7]
                rare = {w for w in sample if len(w) >= 4 and w not in early_terms}
                if len(rare) < 2 or min(map(len, sample)) < 2:
                    continue
                phrase = ' '.join(sample)
                matched = [name for name, text in whole.items() if phrase in text]
                if matched == [paper['filename']]:
                    choice = {'filename': paper['filename'], 'page': chunk.page, 'phrase': phrase,
                              'source_chunk_id': chunk.chunk_id, 'source_quote': chunk.text,
                              'distinctive_terms': sorted(rare), 'expected_filenames': matched}
                    break
            if choice:
                break
        if choice:
            examples.append(choice)
    assert len(examples) >= 6, 'Not enough unique late-page phrases; do not fabricate labels'
    # Alternate document-disjoint development and held-out sets, frozen now.
    examples = examples[:12]
    for index, item in enumerate(examples):
        item['split'] = 'development' if index % 2 == 0 else 'heldout'
        item['case_id'] = 'B-' + str(41 + index)
    save(OUT / 'deep-challenge.json', {'kind': 'constructed late-page literal diagnostic, not official or random research tasks',
         'cases': examples, 'initial_page_limit': initial_limit, 'corpus_sha256': hashlib.sha256((OUT / 'corpus.json').read_bytes()).hexdigest(),
         'label_policy': 'Unique literal phrase in all qualified full texts, document-disjoint split before retrieval measurements'})
    print(json.dumps({'qualified': len(corpus), 'excluded': len(excluded), 'late_page_cases': len(examples),
                      'model_calls': 0}, ensure_ascii=False))


if __name__ == '__main__':
    main()
