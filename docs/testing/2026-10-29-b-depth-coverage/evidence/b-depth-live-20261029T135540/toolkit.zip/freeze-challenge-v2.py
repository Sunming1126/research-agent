"""Native source-qualified continuous-prose labels; no retrieval/model decisions used."""
import hashlib
import json
import os
from pathlib import Path
import re
import unicodedata

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / '镜像测试/depth-optimization-20261029'
LIB = ROOT / '科研资料/2026-10-29-扩充论文库/pdfs'


def canonical(text):
    value = unicodedata.normalize('NFKC', text).lower()
    value = re.sub(r'(?<=[a-z])-\s*\n\s*(?=[a-z])', '', value)
    return re.sub(r'\s+', ' ', value)


def main():
    assert os.environ.get('ANIC_NATIVE_ORCHESTRATOR_SESSION_ID') == 'session-9c903d0e-5884-44fe-bc7f-3719da00864b'
    from research_agent.core.models import MaterialRef
    from research_agent.rag.materials import DocumentParser, Chunker
    corpus = json.loads((DATA / 'corpus.json').read_text(encoding='utf-8'))
    parser = DocumentParser()
    parser.extract_tables = False
    initial = 4 if len(corpus['papers']) >= 50 else 8
    contents = {}
    for row in corpus['papers']:
        path = LIB / row['filename']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
        pages = parser.pages(MaterialRef(path, path.name, 'pdf', row['sha256']))
        chunks = Chunker().chunk(MaterialRef(path, path.name, 'pdf', row['sha256']), pages)
        contents[path.name] = {'pages': pages, 'chunks': chunks,
            'whole': canonical('\n'.join(p[1] for p in pages)),
            'prefix': canonical('\n'.join(p[1] for p in pages if p[0] <= initial))}
    early_terms = set(re.findall(r'[a-z]{4,}', ' '.join(c['prefix'] for c in contents.values())))
    examples = []
    for row in sorted(corpus['papers'], key=lambda p: hashlib.sha256(p['sha256'].encode()).hexdigest()):
        choice = None
        for chunk in contents[row['filename']]['chunks']:
            if not chunk.page or chunk.page < max(8, initial + 3) or chunk.kind != 'text':
                continue
            if len(re.findall(r'\b(?:19|20)\d{2}\b', chunk.text)) >= 4:
                continue  # Dense bibliography/citation blocks are not prose positives.
            text = canonical(chunk.text)
            # No removal of numbers/punctuation to manufacture a continuous
            # phrase. Only whitespace and genuine line-wrap hyphens normalize.
            words = list(re.finditer(r'\b[a-z]{2,}\b', text))
            for i in range(len(words) - 6):
                selected = words[i:i+7]
                if any(not text[a.end():b.start()].isspace() for a, b in zip(selected, selected[1:])):
                    continue
                sample = [m.group() for m in selected]
                phrase = ' '.join(sample)
                if 'et al' in phrase:
                    continue
                rare = {w for w in sample if len(w) >= 4 and w not in early_terms}
                if not rare or any(phrase in c['prefix'] for c in contents.values()):
                    continue
                matched = [name for name, c in contents.items() if re.search(r'(?<![a-z])' + re.escape(phrase) + r'(?![a-z])', c['whole'])]
                if matched == [row['filename']]:
                    choice = {'filename': row['filename'], 'page': chunk.page, 'phrase': phrase,
                        'source_chunk_id': chunk.chunk_id, 'source_quote': chunk.text,
                        'distinctive_terms': sorted(rare), 'expected_filenames': matched}
                    break
            if choice:
                break
        if choice:
            examples.append(choice)
        if len(examples) == 12:
            break
    assert len(examples) >= 8, 'Too few genuine prose examples; do not fabricate'
    for i, example in enumerate(examples):
        example.update(case_id='B-' + str(41+i), split='development' if i % 2 == 0 else 'heldout')
    target = DATA / 'deep-challenge-v2.json'
    assert not target.exists(), 'Preserve frozen labels'
    target.write_text(json.dumps({'version': 2, 'initial_page_limit': initial,
        'cases': examples, 'corpus_sha256': hashlib.sha256((DATA / 'corpus.json').read_bytes()).hexdigest(),
        'kind': 'constructed continuous-prose late-page lexical diagnostic, not random semantic tasks or official gold',
        'label_policy': 'NFKC and line-wrap normalization, literal contiguous words, no dense citation blocks, unique full-corpus phrase, absent prefixes; split before v2 measurements',
        'v1_status': 'Not a primary benchmark: audit found ligature loss, removed numeric columns and bibliography positives. Preserve v1 artifacts; no production parameters changed based on v1 results.'},
        ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'v2_cases_frozen': len(examples), 'qualified_corpus': len(corpus['papers']), 'target_real_model_calls': 0}))


if __name__ == '__main__':
    main()
