"""One bounded contract repair of failed assessments; original attempts immutable.

The source bundle and report are copied from the original request. Feedback only
describes objective JSON/quotation violations, never requests a favorable verdict.
"""
import argparse
import json
import os
from pathlib import Path

from quality_assess_20261029 import ROOT, canon, save


def validate(response, prompt):
    problems=[]
    choice=response['choices'][0]
    if choice.get('finish_reason')!='stop':
        problems.append('finish_reason must be stop')
    facts=json.loads(choice['message']['content'])['facts']
    if not isinstance(facts,list) or not 1<=len(facts)<=12:
        problems.append('facts must contain 1..12 items; split or sample without changing the evidence standard')
    known={s['source_id']:s for s in prompt['sources']}
    for number,fact in enumerate(facts):
        prefix=f'facts[{number}] '
        if fact.get('verdict') not in {'supported','contradicted','not_in_evidence','uncertain'}:
            problems.append(prefix+'invalid verdict')
        if not isinstance(fact.get('sentence'),str) or len(canon(fact['sentence']))<8 or canon(fact['sentence']) not in canon(prompt['report']):
            problems.append(prefix+'sentence must be a continuous report sentence')
        ids=fact.get('source_ids',[])
        if not isinstance(ids,list) or not set(ids)<=set(known):
            problems.append(prefix+'unknown source ids')
            continue
        if fact.get('verdict') in {'supported','contradicted'}:
            quote=canon(fact.get('source_quote',''))
            if not(len(quote)>=12 and ids and any(quote in canon(known[i]['quote']) for i in ids)):
                problems.append(prefix+'source_quote must be one continuous verbatim excerpt; ellipses or joined excerpts are invalid')
    return facts,problems


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--directory',type=Path,required=True)
    out=parser.parse_args().directory.resolve()
    assert out.is_relative_to(ROOT/'镜像测试/runs')
    assert os.environ.get('ANIC_NATIVE_ORCHESTRATOR_SESSION_ID')=='session-9c903d0e-5884-44fe-bc7f-3719da00864b'
    from magic_api_bridge import MagicAPI
    previous=Path(json.loads((ROOT/'.session-audit/quality-assess-latest.json').read_text())['run'])
    original=json.loads((previous/'summary.json').read_text(encoding='utf-8'))
    assert original['complete']
    rows=[]
    for old in original['results']:
        if old['status']=='assessed':
            rows.append(dict(old,attempt='original',original_run=previous.name))
            continue
        name=old['case_id']+'-'+old['variant']
        folder=previous/name/'judge-calls/01'
        request=json.loads((folder/'request.json').read_text(encoding='utf-8'))
        response=json.loads((folder/'response.json').read_text(encoding='utf-8'))
        prompt=json.loads(request['messages'][1]['content'])
        _,problems=validate(response,prompt)
        assert problems
        directory=out/name
        directory.mkdir()
        save(directory/'original-contract-errors.json',{'original_run':previous.name,'errors':problems})
        messages=request['messages']+[
            {'role':'assistant','content':response['choices'][0]['message']['content']},
            {'role':'user','content':'仅修正以下格式或引用连续性错误，仍只依据原始sources。不得凭反馈将结论改成supported；无法在连续摘录支持时保留not_in_evidence/uncertain。最多12项，明确排除拟议研究本身。不要改变报告或sources。错误：'+json.dumps(problems,ensure_ascii=False)}]
        api=MagicAPI()
        try:
            fixed,_=api.complete(dict(request,messages=messages),directory/'judge-calls/01',timeout=75)
            facts,issues=validate(fixed,prompt)
            result={'status':'assessment_failed','contract_errors':issues} if issues else {
                'status':'assessed','facts':facts,'sampled_paper_facts':len(facts),
                'verdict_counts':{v:sum(f['verdict']==v for f in facts) for v in ['supported','contradicted','not_in_evidence','uncertain']}}
        except Exception as exc:
            result={'status':'assessment_failed','error_type':type(exc).__name__}
        result.update(case_id=old['case_id'],variant=old['variant'],attempt='one_contract_repair',original_run=previous.name,
            limits='Same-provider sampled assessment, not human gold; quotation presence does not prove semantic entailment')
        save(directory/'result.json',result)
        rows.append(result)
        save(out/'summary.json',{'results':rows,'complete':False,'original_assessments_passed':1,'original_assessments_failed':3})
        if api.quota_exhausted.is_set():
            return
    save(out/'summary.json',{'results':rows,'complete':True,'original_assessments_passed':1,'original_assessments_failed':3,
        'repair_limit_per_failed_report':1,'evaluator_role':'same-provider source-only diagnostic; not independent human gold'})
    print(json.dumps({'reports':len(rows),'assessed':sum(r['status']=='assessed' for r in rows)}))


if __name__=='__main__':
    main()
