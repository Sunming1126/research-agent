"""Native fixed-session coordinator for cross-task quality work, no headless entry."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent.parent
SOURCE = ROOT / '协同开发/research-agent-stability-20261027'
BASE = ROOT / '镜像测试/审核/2026-10-29-quality-baseline-a329dd6/source'
SID = 'session-9c903d0e-5884-44fe-bc7f-3719da00864b'
WID = 'c61ec5e8-9932-4ef5-9709-fed302ad7355'
PY312 = ROOT / '镜像测试/runtime/windows-python312/python.exe'


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


def proof(stage):
    from native_workspace_harness import workspace, native_rows, selection
    assert SID in workspace()['sessionIds']
    selection()
    request = json.loads((ROOT / '.session-audit/quality-request-20261029.json').read_text())
    assert request['stage'] == stage and request['session_id'] == SID and request['workspace_id'] == WID
    for _ in range(40):
        rows, _ = native_rows(SID)
        for row in rows:
            if row.get('seq', 0) <= request['before_seq'] or row.get('type') != 'assistant/message':
                continue
            for part in row.get('data', {}).get('message', {}).get('content', []):
                text = json.dumps(part, ensure_ascii=False)
                if part.get('type') == 'tool-call' and 'quality_20261029.py' in text and '--stage '+stage in text:
                    return {'session_id': SID, 'workspace_id': WID, 'native_tool_execution_verified': True,
                            'magic_selection_verified': True, 'native_tool_sha256': hashlib.sha256(text.encode()).hexdigest()}
        time.sleep(.2)
    raise RuntimeError('Fresh native invocation not verified')


def tests(source, out, paths):
    from b_depth_20261029 import run_tests
    return run_tests(source, out, paths)


def script(source, path, out, *args, timeout=600):
    out.mkdir()
    paths = [str(source), str(source/'src'), str(ROOT/'镜像测试/runtime/py312-windows'), str(ROOT/'镜像测试')]
    boot = 'import sys,runpy;sys.path[:0]='+repr(paths)+';runpy.run_path('+repr(str(path))+',run_name="__main__")'
    cmd = [str(PY312), '-X', 'utf8', '-c', boot, *map(str, args)]
    done = subprocess.run(cmd, cwd=source, capture_output=True, timeout=timeout)
    (out/'stdout.txt').write_bytes(done.stdout)
    (out/'stderr.txt').write_bytes(done.stderr)
    save(out/'execution.json', {'returncode':done.returncode})
    return done


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', choices=['environment','counterexamples','regression','retrieval','live','matrix'], required=True)
    stage = parser.parse_args().stage
    native = proof(stage)
    out = ROOT/'镜像测试/runs'/('quality-'+stage+'-'+time.strftime('%Y%m%dT%H%M%S'))
    out.mkdir(parents=True, exist_ok=False)
    save(out/'native-proof.json', native)
    save(ROOT/f'.session-audit/quality-{stage}-latest.json', {'run':str(out)})
    sources = {p.relative_to(SOURCE).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
               for p in SOURCE.rglob('*.py') if '__pycache__' not in p.parts}
    save(out/'source-files.json', sources)
    with zipfile.ZipFile(out/'source-snapshot.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
        for name,digest in sources.items():
            data=(SOURCE/name).read_bytes();assert hashlib.sha256(data).hexdigest()==digest
            z.writestr(name,data)
    tools = [Path(__file__), ROOT/'镜像测试/b_depth_20261029.py']
    tools += list((ROOT/'镜像测试').glob('quality_*_20261029.py'))
    with zipfile.ZipFile(out/'toolkit.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
        for path in sorted(set(tools)):
            z.writestr(path.name, path.read_bytes())
    os.environ.update(ANIC_NATIVE_ORCHESTRATOR_SESSION_ID=SID, RESEARCH_RUNTIME='local',
                      AGENTHACK_TELEMETRY_REQUIRED='false',PYTHONDONTWRITEBYTECODE='1')
    if stage == 'environment':
        try:
            done=subprocess.run(['docker','version','--format','{{json .Server}}'],capture_output=True,timeout=15)
            (out/'docker-stdout.txt').write_bytes(done.stdout)
            (out/'docker-stderr.txt').write_bytes(done.stderr)
            result={'docker_returncode':done.returncode,'server_available':done.returncode==0}
        except (OSError,subprocess.TimeoutExpired) as exc:
            result={'server_available':False,'error_type':type(exc).__name__}
        result.update(target_real_model_calls=0, agent_functional_tests=0)
        save(out/'summary.json',result);print(json.dumps(result));return
    if stage == 'counterexamples':
        test=SOURCE/'tests/test_quality_counterexamples.py'
        frozen=out/'frozen-tests'/test.name
        frozen.parent.mkdir()
        frozen.write_bytes(test.read_bytes())
        save(out/'test-sha256.json', {'sha256':hashlib.sha256(frozen.read_bytes()).hexdigest()})
        results={v:tests(s,out/v,[frozen]) for v,s in [('baseline',BASE),('candidate',SOURCE)]}
        save(out/'summary.json',results);return
    if stage == 'regression':
        test=SOURCE/'tests/test_quality_counterexamples.py'
        frozen=out/'frozen-tests'/test.name
        frozen.parent.mkdir()
        frozen.write_bytes(test.read_bytes())
        save(out/'test-sha256.json', {'sha256':hashlib.sha256(frozen.read_bytes()).hexdigest()})
        baseline=tests(BASE,out/'baseline-counterexamples',[frozen])
        candidate=tests(SOURCE,out/'candidate-counterexamples',[frozen])
        result=tests(SOURCE,out/'candidate',[SOURCE/'tests'])
        result.update(baseline_counterexamples=baseline,candidate_counterexamples=candidate)
        save(out/'summary.json',result);raise SystemExit(result['returncode'])
    if stage in {'retrieval','matrix','live'}:
        path=ROOT/'镜像测试'/('quality_'+stage+'_20261029.py')
        if not path.is_file():
            raise RuntimeError('Stage not prepared; do not infer it passed')
        done=script(SOURCE,path,out/'execution','--directory',str(out),timeout=1500)
        print(done.stdout.decode('utf-8',errors='replace')[-2000:],flush=True)
        raise SystemExit(done.returncode)


if __name__=='__main__':
    main()
