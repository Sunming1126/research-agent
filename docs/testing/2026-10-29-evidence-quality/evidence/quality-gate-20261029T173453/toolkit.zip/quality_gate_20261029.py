"""Native offline end-to-end comparison on frozen real late-page phrases.

The deterministic reader tests evidence delivery only. It cannot estimate real
LLM relevance judgments or competition scores.
"""
import argparse
import ctypes
from ctypes import wintypes
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import unicodedata
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parent.parent
SOURCE = ROOT / '协同开发/research-agent-stability-20261027'
BASE = ROOT / '镜像测试/审核/2026-10-29-quality-baseline-a329dd6/source'
DATA = ROOT / '镜像测试/depth-optimization-20261029'
LIB = ROOT / '科研资料/2026-10-29-扩充论文库/pdfs'
SID = 'session-9c903d0e-5884-44fe-bc7f-3719da00864b'


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def words(text):
    text = unicodedata.normalize('NFKC', text).lower()
    text = re.sub(r'(?<=[a-z])-\s*\n\s*(?=[a-z])', '', text)
    return re.sub(r'\s+', ' ', text)


def peak_mib():
    class Counters(ctypes.Structure):
        _fields_ = [('cb', wintypes.DWORD), ('PageFaultCount', wintypes.DWORD)] + [
            (name, ctypes.c_size_t) for name in ['PeakWorkingSetSize', 'WorkingSetSize', 'QuotaPeakPagedPoolUsage',
            'QuotaPagedPoolUsage', 'QuotaPeakNonPagedPoolUsage', 'QuotaNonPagedPoolUsage', 'PagefileUsage', 'PeakPagefileUsage']]
    counters = Counters()
    counters.cb = ctypes.sizeof(counters)
    handle = ctypes.windll.kernel32.GetCurrentProcess()
    ctypes.windll.psapi.GetProcessMemoryInfo.argtypes = [ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD]
    assert ctypes.windll.psapi.GetProcessMemoryInfo(handle, ctypes.byref(counters), counters.cb)
    return round(counters.PeakWorkingSetSize / 2**20, 3)


def worker(directory, case_id):
    from research_agent.core.config import Settings
    from research_agent.core.session import CaseSession
    from research_agent.rag.materials import DocumentIndex
    from research_agent.rag.retrieval import HybridRetriever, QueryPlan
    from research_agent.workflows.tasks import TaskHandlers
    corpus = json.loads((DATA / 'corpus.json').read_text(encoding='utf-8'))
    labels = json.loads((DATA / 'deep-challenge-v2.json').read_text(encoding='utf-8'))
    files = [row['filename'] for row in corpus['papers']]
    for row in corpus['papers']:
        assert hashlib.sha256((LIB / row['filename']).read_bytes()).hexdigest() == row['sha256']
    settings = Settings(ROOT, directory / 'out', 'depth_benchmark', material_roots=[LIB])
    index = DocumentIndex(settings, directory / 'cache')
    index.parser.extract_tables = False
    pages = 2 if len(files) >= 250 else 4 if len(files) >= 50 else 8
    start = time.monotonic()
    chunks = index.build(files, page_limit=pages, tolerate_pdf_errors=True)
    cold = round(time.monotonic() - start, 3)
    start = time.monotonic()
    index.build(files, page_limit=pages, tolerate_pdf_errors=True)
    warm = round(time.monotonic() - start, 3)
    results = []
    for example in [r for r in labels['cases'] if r['case_id'] == case_id]:
        phrase = example['phrase']
        class Reader:
            def __init__(self):
                self.requests = []
            def json(self, stage, payload, **kwargs):
                assert stage == 'retrieve'
                self.requests.append(payload)
                return {'papers': [{'filename': p['filename'], 'decision': 'include', 'relevant': True,
                       'chunk_ids': [c['chunk_id'] for c in p['chunks']],
                       'reason': 'The requested literal phrase occurs in the supplied original paper text.'}
                       for p in payload['candidates'] if any(phrase in words(c['text']) for c in p['chunks'])]}
        reader = Reader()
        handler = TaskHandlers(reader, 'depth_benchmark')
        handler.document_expander = index.expand_documents
        method = getattr(index, 'probe_deep_pages', None)
        if method:
            handler.document_probe = lambda queries: method(queries, pages)
        task = SimpleNamespace(case_id=example['case_id'], input='查找正文包含此连续短语的论文：' + phrase,
                               to_dict=lambda: {'input': '查找正文包含此连续短语的论文：' + phrase})
        start = time.monotonic()
        with CaseSession(example['case_id'], 170).activate():
            answer = handler.retrieval(task, HybridRetriever(chunks), QueryPlan(phrase))
        selected = sorted(row['filename'] for row in answer['papers'])
        row = {'case_id': example['case_id'], 'split': example['split'], 'actual': selected,
               'expected': example['expected_filenames'], 'exact': selected == example['expected_filenames'],
               'seconds': round(time.monotonic() - start, 3), 'mock_reader_batches': len(reader.requests),
               'trace': handler.retrieval_trace}
        results.append(row)
        save(directory / 'result.json', {'results': results, 'cold_index_seconds': cold, 'warm_index_seconds': warm,
             'initial_chunks': len(chunks), 'qualified_papers': len(files), 'peak_working_set_mib': peak_mib(),
             'target_real_model_calls': 0, 'material_errors': index.errors,
             'environment': 'Unrestricted Windows host source process; not Linux or CPU/memory hard-limit acceptance'})
    print(json.dumps({'actual_cases': len(results), 'exact': sum(r['exact'] for r in results), 'directory': str(directory)}))


def main():
    assert os.environ.get('ANIC_NATIVE_ORCHESTRATOR_SESSION_ID') == SID
    parser=argparse.ArgumentParser()
    parser.add_argument('--directory',type=Path)
    parser.add_argument('--worker',type=Path)
    parser.add_argument('--case-id')
    args=parser.parse_args()
    if args.worker:
        return worker(args.worker,args.case_id)
    audit=json.loads((DATA/'label-audit-v2.json').read_text(encoding='utf-8'))
    parent=ROOT/'镜像测试/runs'/('quality-gate-measurements-'+time.strftime('%Y%m%dT%H%M%S'))
    parent.mkdir()
    results=[]
    for index,identifier in enumerate(audit['primary_case_ids']):
        order=[('baseline',BASE),('candidate',SOURCE)]
        if index%2:order.reverse()
        for variant,source in order:
            directory=parent/(identifier+'-'+variant)
            directory.mkdir()
            paths=[str(source),str(source/'src'),str(ROOT/'镜像测试/runtime/py312-windows')]
            boot='import sys,runpy;sys.path[:0]='+repr(paths)+';runpy.run_path('+repr(str(Path(__file__)))+',run_name="__main__")'
            cmd=[sys.executable,'-X','utf8','-c',boot,'--worker',str(directory),'--case-id',identifier]
            done=subprocess.run(cmd,cwd=source,capture_output=True,timeout=120)
            (directory/'stdout.txt').write_bytes(done.stdout)
            (directory/'stderr.txt').write_bytes(done.stderr)
            assert done.returncode==0
            data=json.loads((directory/'result.json').read_text(encoding='utf-8'))
            row=dict(data['results'][0],variant=variant,peak_working_set_mib=data['peak_working_set_mib'])
            results.append(row)
            save(parent/'summary.json',{'results':results,'complete':False,'target_real_model_calls':0})
            print(identifier,variant,row['exact'],flush=True)
    save(parent/'summary.json',{'results':results,'complete':True,'target_real_model_calls':0,
         'limits':'Same frozen prior diagnostic questions, alternating fresh processes; single observation, host load not controlled'})
    save(ROOT/'.session-audit/quality-gate-measurements-latest.json',{'run':str(parent)})

if __name__=='__main__':main()
