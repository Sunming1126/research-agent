"""Fresh paired cross-task model comparison; gold/checks stay outside workers."""
import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent.parent
SOURCE=ROOT/'协同开发/research-agent-stability-20261027'
BASE=ROOT/'镜像测试/审核/2026-10-29-quality-baseline-a329dd6/source'


def save(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def evaluate(row,item):
    answer=row.get('answer',{})
    ready=row.get('status')=='completed' and row.get('disk_matches') is True
    if item['check']=='exact_names':
        actual={p['filename'] for p in answer.get('papers',[])}
        expected=set(item['expected_filenames'])
        return {'check_passed':ready and actual==expected,'hits':len(actual&expected),
                'expected':len(expected),'false_positives':sorted(actual-expected),'missed':sorted(expected-actual)}
    if item['check']=='sixty_ms':
        # A small numerical control, not a broad Chat quality score.
        return {'check_passed':ready and bool(re.search(r'60\s*(?:毫秒|ms)',answer.get('answer',''),re.I))
                               and bool(answer.get('clarifying_question'))}
    if item['check']=='materials_missing':
        return {'check_passed':ready and answer.get('status')=='materials_missing'
                and all(m.get('observed') is None for m in answer.get('metrics',[]))
                and row.get('target_real_model_calls')==0}
    return {'check_passed':ready,'report_semantics': 'pending independent source-based assessment; format alone is not factual correctness'}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--directory',type=Path,required=True)
    out=parser.parse_args().directory.resolve()
    assert out.is_relative_to(ROOT/'镜像测试/runs')
    assert os.environ.get('ANIC_NATIVE_ORCHESTRATOR_SESSION_ID')=='session-9c903d0e-5884-44fe-bc7f-3719da00864b'
    manifest=json.loads((ROOT/'镜像测试/quality-20261029/benchmark.json').read_text(encoding='utf-8'))
    save(out/'benchmark.json',manifest)
    results=[]
    for index,item in enumerate(manifest['cases']):
        order=[('baseline',BASE),('candidate',SOURCE)]
        if index%2:
            order.reverse()
        for variant,source in order:
            directory=out/(item['task']['case_id']+'-'+variant)
            directory.mkdir()
            save(directory/'input.json',item['task'])  # No evaluator-only source_facts.
            paths=[str(source),str(source/'src'),str(ROOT/'镜像测试/runtime/py312-windows'),str(ROOT/'镜像测试')]
            worker=ROOT/'镜像测试/quality_live_worker_20261029.py'
            boot='import sys,runpy;sys.path[:0]='+repr(paths)+';runpy.run_path('+repr(str(worker))+',run_name="__main__")'
            cmd=[sys.executable,'-X','utf8','-c',boot,'--directory',str(directory)]
            try:
                done=subprocess.run(cmd,cwd=source,capture_output=True,timeout=220)
                (directory/'stdout.txt').write_bytes(done.stdout)
                (directory/'stderr.txt').write_bytes(done.stderr)
                row=json.loads((directory/'result.json').read_text(encoding='utf-8')) if (directory/'result.json').is_file() else {'status':'setup_failed','returncode':done.returncode}
            except subprocess.TimeoutExpired as exc:
                (directory/'stdout.txt').write_bytes(exc.stdout or b'')
                (directory/'stderr.txt').write_bytes(exc.stderr or b'')
                row={'status':'worker_timeout','disk_matches':False,'target_real_model_calls':None,'usage_unknown':True}
                save(directory/'worker-timeout.json',row)
            row.update(evaluate(row,item),case_id=item['task']['case_id'],function=item['task']['function'],
                       category=item['category'],variant=variant)
            results.append(row)
            save(out/'summary.json',{'results':results,'complete':False,'image_acceptance':False})
            print(json.dumps({k:v for k,v in row.items() if k not in {'answer','retrieval_trace','internal_audit'}},ensure_ascii=False),flush=True)
            if row.get('quota_exhausted'):
                return
    save(out/'summary.json',{'results':results,'complete':True,'image_acceptance':False})


if __name__=='__main__':
    main()
