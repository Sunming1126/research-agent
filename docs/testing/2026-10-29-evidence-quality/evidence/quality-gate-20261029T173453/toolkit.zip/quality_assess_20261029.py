"""Source-only atomic fact assessment, separate from generation and its self-audit.

Same-provider model assessment is a diagnostic, not an independent human gold
standard. It samples up to twelve paper facts and retains all uncertain cases.
"""
import argparse
import json
import os
from pathlib import Path
import re
import unicodedata

ROOT=Path(__file__).resolve().parent.parent


def save(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def canon(value):
    return ''.join(c for c in unicodedata.normalize('NFKC',value).casefold() if c.isalnum())


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--directory',type=Path,required=True)
    out=parser.parse_args().directory.resolve()
    assert out.is_relative_to(ROOT/'镜像测试/runs')
    assert os.environ.get('ANIC_NATIVE_ORCHESTRATOR_SESSION_ID')=='session-9c903d0e-5884-44fe-bc7f-3719da00864b'
    from magic_api_bridge import MagicAPI
    live=Path(json.loads((ROOT/'.session-audit/quality-live-latest.json').read_text())['run'])
    summaries=json.loads((live/'summary.json').read_text(encoding='utf-8'))
    assert summaries['complete']
    results=[]
    for row in summaries['results']:
        if row['function'] not in {'Survey','Idea'} or row['status']!='completed':
            continue
        source=live/(row['case_id']+'-'+row['variant'])
        internal_paths=list((source/'output/data/b_comparison/work'/row['case_id']).glob('*/evidence.json'))
        assert len(internal_paths)==1
        data=json.loads(internal_paths[0].read_text(encoding='utf-8'))
        ledger=data['claims']
        counts={}
        sources=[]
        for evidence in ledger:
            name=evidence['filename']
            if counts.get(name,0)>=5:
                continue
            counts[name]=counts.get(name,0)+1
            sources.append({'source_id':evidence['evidence_id'],'filename':name,'page':evidence['page'],
                            'quote':evidence['quote'],'scope':'authorized excerpt; mention alone does not establish original authorship'})
        assert sources
        directory=out/(row['case_id']+'-'+row['variant'])
        directory.mkdir()
        prompt={'report':row['answer']['markdown'],'sources':sources,
                'reference_map':{str(i+1):name for i,name in enumerate(sorted(counts))}}
        system=('你是独立执行的事实核查员，不知道生成器版本，也不看其自审结论。只依据给定sources，不联网、不借常识补充。'
          '从report中逐字摘出最多12条可检验的论文事实，尽量覆盖所有指定论文。每项sentence必须是报告的连续原句。'
          '原创待验证方案、拟议参数不是已完成论文事实，不能当伪造实测；只检查其是否明确标注。'
          '逐项verdict为supported/contradicted/not_in_evidence/uncertain；缺少摘录支持仅表示not_in_evidence，不能断言论文没做。'
          'supported或contradicted必须给source_ids、逐字连续source_quote，并解释证据如何支持或反驳，不能把引用存在等同于事实正确。'
          '注意相关工作与本篇贡献、否定、实验条件、比较对象和原始方法归属。'
          '只输出JSON对象facts数组，每项sentence,verdict,source_ids,source_quote,reason。不得输出总体满分保证。')
        api=MagicAPI()
        try:
            response,_=api.complete({'model':api.model,'messages':[{'role':'system','content':system},
                {'role':'user','content':json.dumps(prompt,ensure_ascii=False)}],'max_tokens':2600,'stream':False,
                'temperature':0,'thinking':{'type':'disabled'},'response_format':{'type':'json_object'}},
                directory/'judge-calls'/'01',timeout=75)
            choice=response['choices'][0]
            assert choice.get('finish_reason')=='stop'
            facts=json.loads(choice['message']['content'])['facts']
            assert isinstance(facts,list) and 1<=len(facts)<=12
            known={s['source_id']:s for s in sources}
            for fact in facts:
                assert fact['verdict'] in {'supported','contradicted','not_in_evidence','uncertain'}
                assert isinstance(fact['sentence'],str) and len(canon(fact['sentence']))>=8
                assert canon(fact['sentence']) in canon(prompt['report'])
                ids=fact.get('source_ids',[])
                assert isinstance(ids,list) and set(ids)<=set(known)
                if fact['verdict'] in {'supported','contradicted'}:
                    quote=canon(fact['source_quote'])
                    assert len(quote)>=12 and ids and any(quote in canon(known[i]['quote']) for i in ids)
            result={'status':'assessed','facts':facts,'sampled_paper_facts':len(facts),
                'verdict_counts':{v:sum(f['verdict']==v for f in facts) for v in ['supported','contradicted','not_in_evidence','uncertain']},
                'limits':'Same-provider sampled fact assessment, not exhaustive human judgment; missing excerpt is not a false paper claim'}
        except Exception as exc:
            result={'status':'assessment_failed','error_type':type(exc).__name__}
        result.update(case_id=row['case_id'],variant=row['variant'])
        save(directory/'result.json',result)
        results.append(result)
        save(out/'summary.json',{'results':results,'complete':False,'evaluation_role':'separate same-provider source-only assessor'})
        if api.quota_exhausted.is_set():
            return
    save(out/'summary.json',{'results':results,'complete':True,'evaluation_role':'separate same-provider source-only assessor'})
    print(json.dumps({'reports_attempted':len(results),'assessed':sum(r['status']=='assessed' for r in results)},ensure_ascii=False))


if __name__=='__main__':
    main()
